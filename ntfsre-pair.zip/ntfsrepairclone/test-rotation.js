#!/usr/bin/env node
// "Static image" check: rendering twice must give byte-identical output (no rotation / tint / animation).
// (The old version printed OK on every code path, so it could never fail.)
const fs = require('fs');
const path = require('path');
let lib;
try { lib = require('static-chafa'); } catch (e) { console.log('SKIP: static-chafa not loadable on this platform.'); process.exit(0); }
const { Chafa, PixelMode } = lib;
const buf = fs.readFileSync(path.join(__dirname, 'redkeys.png'));
const make = () => new Chafa({ termW: 70, termH: 18, pixelMode: PixelMode.SYMBOLS, cellW: 8, cellH: 16 });
const a = String(make().render(buf).ansi);
const b = String(make().render(buf).ansi);
if (a !== b) { console.error('FAIL: two renders differ (image is not static)'); process.exit(1); }
console.log('OK: key image render is static and deterministic.');
