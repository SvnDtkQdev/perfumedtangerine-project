#!/usr/bin/env node
// Checks that redkeys.png is a real PNG and that the render keeps the original colours.
const fs = require('fs');
const path = require('path');
const img = path.join(__dirname, 'redkeys.png');
if (!fs.existsSync(img)) { console.error('FAIL: missing redkeys.png'); process.exit(1); }
const buf = fs.readFileSync(img);
if (buf.slice(0, 8).toString('hex') !== '89504e470d0a1a0a') { console.error('FAIL: redkeys.png is not a PNG'); process.exit(1); }

let lib;
try { lib = require('static-chafa'); } catch (e) { console.log('OK: redkeys.png is a valid PNG (colour render skipped: static-chafa not loadable).'); process.exit(0); }
const { Chafa, PixelMode } = lib;
const ansi = String(new Chafa({ termW: 70, termH: 18, pixelMode: PixelMode.SYMBOLS, cellW: 8, cellH: 16 }).render(buf).ansi);
if (!/\x1b\[38;(2|5);/.test(ansi)) { console.error('FAIL: render contains no colour escape sequences'); process.exit(1); }
console.log('OK: redkeys.png is a valid PNG and renders in colour.');
