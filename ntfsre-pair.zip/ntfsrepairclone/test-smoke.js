#!/usr/bin/env node
// Smoke test: start the real UI in a pseudo-terminal and make sure it STAYS ALIVE and shows the menu.
// This is the regression test for "the app exits by itself ~2 seconds after start".
// Uses `script` (util-linux) to provide a real TTY; skipped when it is not available.
const { spawn, spawnSync } = require('child_process');
const path = require('path');

if (process.platform !== 'linux') { console.log('SKIP: smoke test needs Linux.'); process.exit(0); }
if (spawnSync('script', ['--version'], { stdio: 'ignore' }).status !== 0) {
  console.log('SKIP: `script` (util-linux) not found - cannot allocate a pseudo-terminal.');
  process.exit(0);
}

const ALIVE_MS = Number(process.env.SMOKE_ALIVE_MS || 4000);   // the old bug killed the app after ~0.5-2 s
const app = path.join(__dirname, 'index.js');
const cmd = `stty rows 50 cols 120; exec ${JSON.stringify(process.execPath)} ${JSON.stringify(app)}`;
const child = spawn('script', ['-qefc', cmd, '/dev/null'], {
  stdio: ['pipe', 'pipe', 'pipe'],
  env: { ...process.env, TERM: 'xterm-256color' },
});

let out = '';
let exited = null;
const t0 = Date.now();
child.stdout.on('data', d => { out += d.toString(); });
child.stderr.on('data', d => { out += d.toString(); });
child.on('exit', (code, sig) => { exited = { code, sig, at: Date.now() - t0 }; });

const strip = s => s.replace(/\x1b\[[0-9;?]*[ -\/]*[@-~]/g, '');
const done = (ok, msg) => {
  try { child.kill('SIGKILL'); } catch (_) {}
  (ok ? console.log : console.error)((ok ? 'OK: ' : 'FAIL: ') + msg);
  process.exit(ok ? 0 : 1);
};

setTimeout(() => {
  if (exited) return done(false, `app exited by itself after ${exited.at} ms (code ${exited.code}) - it must stay open waiting for input.\n${strip(out).slice(-600)}`);
  if (!strip(out).includes('Select an option')) return done(false, 'app is running but the main menu was not rendered:\n' + strip(out).slice(-600));
  // navigate a little, then quit with Ctrl+C; the process must end and not hang
  child.stdin.write('\x1b[B\x1b[B\x1b[A');
  setTimeout(() => {
    if (exited) return done(false, `app died while navigating the menu (code ${exited.code}).`);
    child.stdin.write('\x03');
    setTimeout(() => {
      if (!exited) return done(false, 'app did not exit after Ctrl+C.');
      done(true, `menu rendered, app stayed alive for ${ALIVE_MS} ms, survived arrow-key navigation and quit on Ctrl+C.`);
    }, 2500);
  }, 800);
}, ALIVE_MS);
