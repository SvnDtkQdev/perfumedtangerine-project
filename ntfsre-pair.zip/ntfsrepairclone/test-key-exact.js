#!/usr/bin/env node
// Renders redkeys.png with the SAME static-chafa settings index.js uses and checks the
// geometry that actually comes out (columns x rows of text cells).
// (The old version passed keys the library ignores - width/height/symbolGlyphs - and so
// silently rendered the 80x24 default while claiming "70x35".)
const fs = require('fs');
const path = require('path');

let lib;
try { lib = require('static-chafa'); } catch (e) {
  console.log('SKIP: static-chafa not loadable on this platform (' + String(e.message).split('\n')[0] + '). The app runs without the image.');
  process.exit(0);
}
const { Chafa, PixelMode, ColorSpace, DitherMode } = lib;

const COLS = 70, ROWS = 18;
const img = path.join(__dirname, 'redkeys.png');
if (!fs.existsSync(img)) { console.error('FAIL: missing redkeys.png'); process.exit(1); }

const chafa = new Chafa({
  termW: COLS, termH: ROWS,
  pixelMode: PixelMode.SYMBOLS, cellW: 8, cellH: 16,   // explicit => no stdin-pausing terminal probe
  symbols: 'block', colorSpace: ColorSpace.RGB, ditherMode: DitherMode.NONE,
});
const out = chafa.render(fs.readFileSync(img));
const lines = String(out.ansi || '').split('\n').filter(Boolean);
const widths = lines.map(l => [...l.replace(/\x1b\[[0-9;?]*[ -\/]*[@-~]/g, '')].length);

if (lines.length !== ROWS) { console.error(`FAIL: expected ${ROWS} rows, got ${lines.length}`); process.exit(1); }
if (Math.max(...widths) !== COLS) { console.error(`FAIL: expected ${COLS} columns, got ${Math.max(...widths)}`); process.exit(1); }
console.log(`OK: rendered ${lines.length} rows x ${Math.max(...widths)} columns (~2:1 on screen).`);
