#!/bin/bash
# NTFS-REPAIR local system dependencies installer
# Builds ntfs-3g/ntfsprogs and e2fsprogs (badblocks) from source into ./deps/usr
# No system package manager required for these binaries (build tools still required).

set -euo pipefail

NTFSREPAIR_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEPS_DIR="$NTFSREPAIR_DIR/deps"
BUILD_DIR="$DEPS_DIR/build"
PREFIX="$DEPS_DIR/usr"
BIN_DIR="$PREFIX/bin"
LIB_DIR="$PREFIX/lib"
INCLUDE_DIR="$PREFIX/include"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log() { echo -e "${CYAN}[NTFS-REPAIR]${NC} $1"; }
success() { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}⚠${NC} $1"; }
error() { echo -e "${RED}✗${NC} $1"; exit 1; }

NTFS3G_VERSION="2022.10.3"
E2FSPROGS_VERSION="1.47.0"
NTFS3G_URL="https://tuxera.com/opensource/ntfs-3g_ntfsprogs-${NTFS3G_VERSION}.tgz"
E2FSPROGS_URL="https://www.kernel.org/pub/linux/kernel/people/tytso/e2fsprogs/v${E2FSPROGS_VERSION}/e2fsprogs-${E2FSPROGS_VERSION}.tar.gz"

mkdir -p "$DEPS_DIR" "$BUILD_DIR" "$BIN_DIR" "$LIB_DIR" "$INCLUDE_DIR"
export PATH="$BIN_DIR:$PATH"
export PKG_CONFIG_PATH="$LIB_DIR/pkgconfig:${PKG_CONFIG_PATH:-}"
export LD_LIBRARY_PATH="$LIB_DIR:${LD_LIBRARY_PATH:-}"
export CFLAGS="${CFLAGS:-} -I$INCLUDE_DIR"
export LDFLAGS="${LDFLAGS:-} -L$LIB_DIR"

fetch() {
  local url="$1" out="$2"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 3 -o "$out" "$url"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$out" "$url"
  else
    error "curl or wget is required to download sources"
  fi
}

check_build_tools() {
  log "Checking build tools..."
  local missing=()
  for t in gcc make tar pkg-config; do
    command -v "$t" >/dev/null 2>&1 || missing+=("$t")
  done
  if [ ${#missing[@]} -gt 0 ]; then
    warn "Missing tools: ${missing[*]}"
    warn "Arch/CachyOS: sudo pacman -S --needed base-devel pkgconf"
    warn "Debian/Ubuntu: sudo apt install build-essential pkg-config"
    warn "Fedora: sudo dnf install gcc make tar pkgconf-pkg-config"
    error "Install the build tools above, then run this script again."
  fi
  success "Basic build tools found"
}

build_ntfs3g() {
  log "Building ntfs-3g_ntfsprogs ${NTFS3G_VERSION}..."
  local tgz="$BUILD_DIR/ntfs-3g_ntfsprogs-${NTFS3G_VERSION}.tgz"
  local src="$BUILD_DIR/ntfs-3g_ntfsprogs-${NTFS3G_VERSION}"
  if [ ! -f "$tgz" ]; then
    fetch "$NTFS3G_URL" "$tgz"
  fi
  rm -rf "$src"
  tar -xzf "$tgz" -C "$BUILD_DIR"
  cd "$src"
  # Everything must stay inside ./deps/usr. Upstream rules (verified in configure.ac and
  # src/Makefile.am of 2022.10.3):
  #  * without --exec-prefix, ntfs-3g/lowntfs-3g are installed to the SYSTEM /bin and
  #    libntfs-3g to the system lib dir ("Use --exec-prefix to override this");
  #  * --enable-mount-helper makes "make install" run `ln -s -f ... /sbin/mount.ntfs-3g`,
  #    which as root would replace the distribution's own mount helper;
  #  * --sbindir keeps mkntfs & co. in $PREFIX/bin where the app looks for them.
  ./configure --prefix="$PREFIX" --exec-prefix="$PREFIX" --sbindir="$BIN_DIR" \
    --disable-static --disable-mount-helper --disable-ldconfig
  make -j"$(nproc 2>/dev/null || echo 2)"
  make install
  success "ntfs-3g_ntfsprogs installed to $PREFIX"
}

build_e2fsprogs() {
  log "Building e2fsprogs ${E2FSPROGS_VERSION} (for badblocks)..."
  local tgz="$BUILD_DIR/e2fsprogs-${E2FSPROGS_VERSION}.tar.gz"
  local src="$BUILD_DIR/e2fsprogs-${E2FSPROGS_VERSION}"
  if [ ! -f "$tgz" ]; then
    fetch "$E2FSPROGS_URL" "$tgz"
  fi
  rm -rf "$src"
  tar -xzf "$tgz" -C "$BUILD_DIR"
  cd "$src"
  # --without-udev-rules-dir/-crond-dir/-systemd-unit-dir: by default e2fsprogs 1.47 detects
  # the SYSTEM udev, cron and systemd directories and `make install` (as root) would write
  # e2scrub rules/units/cron files there, outside ./deps.
  ./configure --prefix="$PREFIX" --disable-elf-shlibs --disable-bsd-shlibs --disable-nls \
    --without-udev-rules-dir --without-crond-dir --without-systemd-unit-dir
  make -j"$(nproc 2>/dev/null || echo 2)"
  make install || warn "e2fsprogs 'make install' reported errors; trying to copy badblocks directly"
  # e2fsprogs installs badblocks into $PREFIX/sbin; the app looks in $PREFIX/bin
  mkdir -p "$BIN_DIR"
  if [ ! -x "$BIN_DIR/badblocks" ]; then
    if [ -x "$PREFIX/sbin/badblocks" ]; then
      cp "$PREFIX/sbin/badblocks" "$BIN_DIR/badblocks"
    elif [ -x "$src/misc/badblocks" ]; then
      cp "$src/misc/badblocks" "$BIN_DIR/badblocks"
    fi
    [ -x "$BIN_DIR/badblocks" ] && chmod +x "$BIN_DIR/badblocks"
  fi
  [ -x "$BIN_DIR/badblocks" ] || error "badblocks was not built; see the make output above"
  success "badblocks installed to $BIN_DIR"
}

write_env_script() {
  cat > "$DEPS_DIR/env.sh" <<EOF
# NTFS-REPAIR local dependencies environment
export NTFSREPAIR_DEPS_DIR="$DEPS_DIR"
export PATH="$BIN_DIR:\$PATH"
export LD_LIBRARY_PATH="$LIB_DIR:\${LD_LIBRARY_PATH:-}"
export PKG_CONFIG_PATH="$LIB_DIR/pkgconfig:\${PKG_CONFIG_PATH:-}"
EOF
  chmod +x "$DEPS_DIR/env.sh"
  success "Wrote $DEPS_DIR/env.sh"
}

summary() {
  log "Verification:"
  for t in ntfsfix ntfs-3g ntfsinfo mkntfs badblocks; do
    if [ -x "$BIN_DIR/$t" ]; then
      success "$t -> $BIN_DIR/$t"
    else
      warn "$t not found in $BIN_DIR"
    fi
  done
  echo
  log "Done. Use local tools with: source \"$DEPS_DIR/env.sh\""
}

main() {
  echo "========================================="
  echo "  NTFS-REPAIR System Dependencies Installer"
  echo "  (local source build into ./deps/usr)"
  echo "========================================="
  echo "Target: $PREFIX"
  echo

  check_build_tools
  build_ntfs3g
  build_e2fsprogs
  write_env_script
  summary
}

main "$@"
