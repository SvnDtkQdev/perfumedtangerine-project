# NTFS-REPAIR

**Version 13.0.9** — created by **Svn DtkQdev**

Terminal-based NTFS diagnostics and repair helper for Linux.

It provides a menu-driven TUI for selecting NTFS volumes and running common checks/fixes using tools such as `ntfsfix`, `ntfsinfo`, `badblocks`, `blkid`, `lsblk`, and kernel logs. Some repairs are best-effort; severe NTFS corruption may require Windows `chkdsk`.

## Features

- **Single title + key image UI**: `NTFS-REPAIR` header and `redkeys.png` rendered in terminal via `static-chafa` as plain text blocks (70x18 cells = wide 2:1, no rotation, no tint). The image shrinks automatically on small terminals and is hidden when the window is shorter than about 38 rows; the app works without it (also if `static-chafa` cannot be loaded).
- **15 menu options** with white brackets and colored marker characters:
  - Initial state: random marker character (white) for each option.
  - On completion: marker changes to a new random character and color (only the character is colored, brackets remain white).
  - Re-run: that option gets a new random marker/color; other completed options keep their current markers.
  - Restart: all markers reset.
- **Multi-volume selection** (option 1): `SPACE` ticks/unticks a volume, `ENTER` confirms, pick `← Back` to leave without changes.
- **Mounting errors check (option 4)**:
  - Runs comprehensive diagnostics (mount state, `findmnt`/`mount`, `ntfsfix -n`, `ntfsinfo -m`, `ntfs-3g.probe` if available, `blkid`, `lsblk`, dmesg/journal filters, `/etc/fstab`) and builds a summary.
  - Displays the full report immediately on first run and after re-runs.
  - Persists the latest report in the main menu until option 4 is run again.
- **ANSI screen clearing** on selections/returns for clean redraws.
- **Global command aliases**: `ntfs-repair`, `ksvn`, `ntfsre-pair`.

## Menu Options

1. **select NTFS volume** – choose one or more NTFS volumes.
2. **auto-fix** – best-effort automatic fixes (`ntfsfix -d`, `ntfsfix -b`, post-check).
3. **check filesystem integrity** – read-only diagnostics (`ntfsfix -n`, `ntfsinfo -m`).
4. **check mounting errors** – detailed mounting/NTFS diagnostics with persisted report.
5. **fix read-only mount** – clears dirty/hibernation-related flags and shows mount hints.
6. **bad blocks fix** – read-only `badblocks` scan and guidance.
7. **repair MFT** – best-effort diagnostics/fix attempts (may require Windows `chkdsk`).
8. **rebuild $Bitmap** – best-effort bitmap/bad-sector-list related fix attempts.
9. **fix $LogFile** – best-effort journal/dirty-state fix attempts.
10. **clear dirty flag** – `ntfsfix -d`.
11. **informations** – app/system/tool status and selected volume details.
12. **system dependencies** – local source-build install/verify/troubleshoot submenu.
13. **help & usage** – usage and safety notes.
14. **advanced options** – extra diagnostics (ntfsinfo, blkid/lsblk/findmnt, mount test, logs).
15. **dd fix bad blocks** – **DANGEROUS**, guided targeted block overwrite only (never whole-disk auto wipe).

## Requirements

- Linux
- Node.js >= 18 (required by the dependencies `figlet` and `inquirer`)
- Root privileges recommended/required for most operations (`sudo`)
- NTFS tools (system or locally built): `ntfsfix`, `ntfsinfo`, `ntfs-3g`/probe utilities, `badblocks`, etc.

## Installation

### From project folder (recommended for this repo)

```bash
cd ~/Documents/ntfsrepair
npm install
# optional: build/install local NTFS/e2fsprogs tools from source
sudo bash ./install-system-deps.sh
# install global commands from this folder
sudo npm install -g .
```

### Using installer script

```bash
cd ~/Documents/ntfsrepair
sudo bash ./install.sh
```

## Running

```bash
sudo ntfs-repair
# or
sudo ksvn
# or
sudo ntfsre-pair
```

Keys: `UP`/`DOWN` move, `ENTER` selects/confirms, `SPACE` ticks a volume in the volume list (`a` = all), `Ctrl+C` quits.

## Tests

```bash
npm test
```

Besides the syntax check and the key-image checks, `test-smoke.js` starts the real UI in a pseudo-terminal (needs `script` from util-linux, skipped otherwise) and fails if the app does not stay open, does not draw the menu, or does not quit on `Ctrl+C`.

## Local dependencies (source build)

`install-system-deps.sh` builds and installs tools into `./deps/usr` (inside the app folder) and generates `./deps/env.sh`.

```bash
source ./deps/env.sh
```

The app automatically prefers local binaries in `./deps/usr/bin` when present.

The installer keeps everything inside `./deps/usr` (`--exec-prefix`, no mount helper, no udev/cron/systemd files) so it never touches system files such as `/sbin/mount.ntfs-3g`. It stops with a clear message when `gcc`/`make`/`tar`/`pkg-config` are missing.

## Safety notes

- **Back up important data first.**
- Unmount volumes before write operations when possible.
- Windows Fast Startup/hibernation can cause NTFS to mount read-only; perform a full Windows shutdown or disable Fast Startup.
- Option 15 (`dd fix bad blocks`) is destructive and writes only to blocks you specify after confirmations.
- Some issues cannot be fully repaired by Linux tools; use Windows `chkdsk /f` (and `/r` if needed) when recommended.

## Project files

- `index.js` – main TUI/application logic
- `redkeys.png` – key image asset
- `install.sh` – npm/global install helper
- `install-system-deps.sh` – local source-build installer for NTFS/e2fsprogs tools
- `package.json` – package metadata and bin commands
- `test-*.js` – checks (`npm test`), including `test-smoke.js` (launches the real UI)

## Troubleshooting

- **The app closes by itself right after the first menu appears** – fixed in 1.0.1. Cause: `static-chafa` was created with `new Chafa()`, whose terminal probe pauses `stdin`, so Node had nothing left to wait for and exited silently (exit code 0). The constructor now receives `pixelMode`, `cellW` and `cellH` explicitly, which disables the probe.
- **No key image shown** – the terminal is too small (see Features) or `static-chafa` has no binary for your platform; option 11 explains which. Everything else works.


## Local run (from install folder)

```bash
sudo ./ntfs-repair
# aliases in the same folder:
sudo ./ksvn
sudo ./ntfsre-pair
```

After `npm install -g .` / `./install.sh`, the same commands are available globally: `ntfs-repair`, `ntfsre-pair`, `ksvn`.
