# NTFS-REPAIR changes

## 13.0.9 fixpack (Svn DtkQdev)

- Main menu after option 4: full hard clear + no full report dump (one-line notice only) so title/key-image/selected volumes stay intact.
- Option 17 warning text updated; force mount adds multi-pass ntfsfix + RO badblocks + last-resort force mount (never badblocks -w).
- Option 2 auto-fix: multi-pass ntfsfix, hiber cleanup, RW verify.
- install.sh: system packages on install; fallback to install-system-deps.sh if ntfsfix still missing.

---

# NTFS-REPAIR changes

## 13.0.9 (Svn DtkQdev) — force mount + clear + deps

- Terminal fully cleared on every menu enter and return to main menu (screen + scrollback + SGR reset).
- New **option 17: force mount** — mandatory data-loss warning, double confirm, aggressive unmount + ntfsfix + force/rw/remove_hiberfile mount only (no safe path).
- **install.sh** installs system packages (ntfs-3g, e2fsprogs/badblocks, util-linux, …) on pacman/apt/dnf/zypper at install time.
- Informations lists all system tools + Node packages + install-time package set.

---

# NTFS-REPAIR changes

## 13.0.9 (Svn DtkQdev)

- Version **13.0.9** and author **Svn DtkQdev** everywhere (app, informations, package.json).
- Option 1 volume list: company/disk name (vendor+model), partition size, disk size, label, transport.
- Main menu selected volumes show `/dev/sdXN (Company Name "label" size)`.
- Option 15 chkdsk kit: stronger offline force, multi-pass ntfsfix, hibernation remove_hiberfile cycles, RO/RW write tests, last-resort recovery loop.

---

# NTFS-REPAIR changes

## 1.3.0.11 (SvN DtkQdev)

- Key image: same size/aspect ratio; **maximum quality** (TRUECOLOR, DIN99D, diffusion dither, workFactor 1.0, preprocessing, symbols=all).
- Progress bars: head now reaches and **replaces the last `#`** (`[----------------------------->$]`), then cyan stars for 3s.
- Option 15 chkdsk kit upgraded: force unmount, multi-pass ntfsfix, repeated dirty clear, bad-sector list, hibernation `remove_hiberfile` mount cycle, structure probe, surface scan, final passes, RO/RW mount+write verification. Aimed at fixing USB/NTFS without Windows when possible.

---

# NTFS-REPAIR changes

## 1.3.0.10 (SvN DtkQdev)

- Clean display per menu: mounting-errors report from option 4 is shown **only on the main menu**. All other menus/screens clear the terminal and draw a clean header (no leftover mounting-errors block).
- New option **15: chkdsk NTFS fix - beta** — multi-phase Linux kit mapped to Windows chkdsk stages (verify → /f-like fix → dirty clear → bad-sector list → structure probes → light surface scan → post-check) using ntfsfix/ntfsinfo/badblocks.
- Former **dd fix bad blocks** renumbered to **option 16**.

---

# NTFS-REPAIR changes

## 1.3.0.9 (SvN DtkQdev)

- Progress bars: wider (60 cells), shared across all menus. Colors: `[` `]` yellow, `-` orange, `>` green, `$` red, `#` grey; order is `>$`. Completion fills the bar with cyan `*` for 3 seconds before disappearing.
- Main menu list markers: `[` `]` always white (progress bars keep yellow brackets).
- Removed the main-menu subtitle line "NTFS Volume Repair Tool - diagnostics and repair helpers for NTFS volumes".
- Volume selection: "← Back (keep current selection)" is the confirmation step — tick volumes, tick Back, then ENTER. Volumes are only applied when Back is selected. Last option is navigable (`loop: true`, larger `pageSize`).
- Key image: same size/aspect ratio; richer symbols + ordered dither for better depth/color fidelity.
- Bad blocks (option 6): fuller kit — read-only badblocks scan + `ntfsfix -n/-b/-d` helpers and Windows chkdsk guidance.
- Informations (option 11): shows Version **1.3.0.9** and Author **SvN DtkQdev**.
- Local launchers in the install folder: `./ntfs-repair`, `./ksvn`, `./ntfsre-pair`. Global commands after install remain `ntfs-repair`, `ntfsre-pair`, `ksvn`.
- package.json version set to 1.3.0.9; author SvN DtkQdev.

---

# Changes in 1.0.1

Line numbers refer to the **original** `index.js` (1305 lines).

## Crash / unusable UI

| # | Where (original) | Problem | Fix |
|---|---|---|---|
| 1 | `index.js:62` `new Chafa()` | **Root cause of "crashes ~2 s after start".** With no arguments, on a TTY, static-chafa runs a ~300 ms terminal probe: it takes over `stdin` and finishes with `stdin.pause()`. When that lands after inquirer has opened the menu, `stdin` is paused, Node's event loop is empty and the process exits silently with code 0. | `pixelMode`, `cellW` and `cellH` are now passed explicitly (all three are needed to disable the probe). |
| 2 | `index.js:7` | `require('static-chafa')` unguarded: no native binary for the platform = crash at startup. | Loaded in `try/catch`; the app runs without the image and option 11 says why. |
| 3 | `index.js:63`, `222` | `width/height/symbolGlyphs` and string values for `colorSpace/ditherMode` are not options of this library and were silently ignored: the image really rendered at the 80x24 default, not "70x35". `pixelMode` stayed on auto-detect, which selects kitty/sixel/iTerm2 graphics on kitty, Konsole, WezTerm, Ghostty... and breaks the text layout. | Correct keys (`termW/termH`, enums), `PixelMode.SYMBOLS`, 70x18 cells (= 2:1), scaled down / hidden on small terminals, rendered once and cached. |
| 4 | `index.js:368-413`, `391`, `405-406` | **Volume selector could not be left**: `ENTER` re-opened the same list forever unless a separate "Confirm selection" entry was ticked first. | `SPACE` ticks, `ENTER` confirms, `← Back` leaves unchanged. The duplicate static marker that contradicted the live tick was removed. |
| 5 | `index.js:494-548`, `651` | Option 4 ran up to 12 `execSync` calls (15 s timeout each) inside an "async" function: whole UI frozen, progress animation dead. | Async runner; the animation keeps running. |
| 6 | `index.js:344`, `558` | Every animation frame cleared the screen and re-decoded the 735 KB PNG: heavy flicker. | Header drawn once, only the 3 progress lines are redrawn in place (erase + draw in one write). |
| 7 | `index.js:168-181`, `169`, `176`, `564` | Every tool lookup spawned `bash -lc` (a login shell); the Informations screen did 12-24 of them. | Pure-JS PATH search with cache (also searches `/sbin`, `/usr/sbin`); no login shells. |

## Wrong results

| # | Where | Problem | Fix |
|---|---|---|---|
| 8 | `index.js:506`, `509`, `533` | Option 4 **always** reported "dirty/unclean", "hibernation" and "integrity issue", even on a healthy volume: the word `mft` appears in every healthy `ntfsfix` run, and the fallback text "No hibernation/chkdsk hints…" contained the words being searched for. | Keyword now needs an error word on the same line; fallback text reworded. Real problems are still detected (tested). |
| 9 | `index.js:505-506`, `1169` | `dmesg ... \| tail \|\| echo "No entries"`: the fallback can never run (pipeline status is `tail`'s) and permission errors were swallowed. | Filtered in JS; a permission error is shown instead of "no entries". |
| 10 | `index.js:731` | `options.includes('ro')` also matches `errors=remount-ro`. | Matches the `ro` mount option only. |

## Robustness / safety

- Every device and tool path put into a shell command is now quoted (`shq`) - folders with spaces no longer break commands.
- Read-only mount test uses `mkdtemp` instead of the predictable `/tmp/ntfsrepair-mounttest-<pid>` (`index.js:1163`).
- Menu descriptions and progress lines are truncated to the terminal width (wrapped lines break redraws).
- Help screen now lists the keyboard shortcuts the menu entry promises; stale "option [s]" text (`index.js:1098`) corrected.
- Fatal errors (`uncaughtException`/`unhandledRejection`) are reported with the cursor restored.

## Installers

- `install-system-deps.sh` (as root) wrote **outside `./deps`**, verified in the upstream sources:
  - ntfs-3g: no `--exec-prefix` -> `ntfs-3g` into the system `/bin`, `libntfs-3g` into the system lib dir; `--enable-mount-helper` -> `ln -s -f ... /sbin/mount.ntfs-3g` (would replace the distro's helper). Now `--exec-prefix --sbindir --disable-mount-helper`.
  - e2fsprogs: udev rules, `/etc/cron.d` job and systemd units of e2scrub. Now `--without-udev-rules-dir --without-crond-dir --without-systemd-unit-dir`.
  - `mkntfs` and `badblocks` were installed to `sbin`, but the app looks in `bin`: now installed/copied to `bin`, failure is fatal instead of `|| true`.
  - Missing `gcc/make/tar/pkg-config` only warned and failed later: now stops with distro-specific commands.
- `install.sh` / `package.json`: Node requirement raised from 14 to 18 (what `figlet` and `inquirer` declare); removed `--allow-scripts=ntfs-repair`, which npm does not recognise.

## Tests

`test-key-exact.js`, `test-key-final.js`, `test-key-colors.js`, `test-rotation.js` were placeholders that could not fail (e.g. "rendered 24 lines at 70x35" while rendering 80x24). They now check real behaviour, and `test-smoke.js` starts the real UI in a pseudo-terminal: it fails on the original code ("exited by itself after ~500 ms") and passes on this version.

## Known, intentionally unchanged

- Options 7, 8, 9 always end with a warning icon (`r1.code === 0 ? 'warning' : 'warning'`); the exit code is in the summary.
- `ensureVolumeUnmountedForWrite()` is defined but never called; write operations rely on `ntfsfix` refusing mounted volumes (only option 15 checks the mount state itself).
- The badblocks scan has a fixed 10-minute timeout, so it will not complete on very large disks.
