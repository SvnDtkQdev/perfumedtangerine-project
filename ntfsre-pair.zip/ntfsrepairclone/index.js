#!/usr/bin/env node

const chalk = require('chalk');
const inquirer = require('inquirer');
const figlet = require('figlet');
const gradient = require('gradient-string');
const boxen = require('boxen');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn, spawnSync } = require('child_process');

// ============================================
// CONFIGURATION & CONSTANTS
// ============================================

const APP_DIR = __dirname;
const APP_VERSION = '13.0.9';
const APP_AUTHOR = 'Svn DtkQdev';
const SPECIAL_CHARS = ['~', '+', '_', '-', '=', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '{', '}', ':', '"', '<', '>', '?', '[', ']', ';', "'", ',', '.', '/', '\\', '|'];
const ALPHANUM_CHARS = ['1', '3', '5', '6', '9', '0', 'i', 'h', 'H', 'x', 'X', 's', 'q', 'k', 'z', 'v', 'n', 'L'];
const MARKER_POOL = [...SPECIAL_CHARS, ...ALPHANUM_CHARS];

const MENU_OPTIONS = [
  { id: 1,  label: 'select NTFS volume',      desc: 'Select NTFS volume(s) for operations (multiple volumes supported)' },
  { id: 2,  label: 'auto-fix',                desc: 'Run safe automatic NTFS fixes on selected volume(s)' },
  { id: 3,  label: 'check filesystem integrity', desc: 'Check NTFS structure/metadata (read-only diagnostics)' },
  { id: 4,  label: 'check mounting errors',   desc: 'Diagnose mounting and NTFS-related errors (shows list on first run)' },
  { id: 5,  label: 'fix read-only mount',     desc: 'Clear dirty/hibernation flags and diagnose read-only mount causes' },
  { id: 6,  label: 'bad blocks fix',          desc: 'Scan for bad blocks and report/guide repair actions' },
  { id: 7,  label: 'repair MFT',              desc: 'Run MFT-related diagnostics and best-effort repair steps' },
  { id: 8,  label: 'rebuild $Bitmap',         desc: 'Clear bad sector list / bitmap-related fix attempts' },
  { id: 9,  label: 'fix $LogFile',            desc: 'Fix journal/log-related issues (dirty log recovery attempts)' },
  { id: 10, label: 'clear dirty flag',        desc: 'Clear NTFS dirty flag (common fix for mount refusal/read-only)' },
  { id: 11, label: 'informations',            desc: 'Display app, system, dependencies, and selected volume information' },
  { id: 12, label: 'system dependencies',     desc: 'Install/verify/troubleshoot local deps (ntfs-3g, ntfsfix, badblocks)' },
  { id: 13, label: 'help & usage',            desc: 'Show help, safety notes, and keyboard shortcuts' },
  { id: 14, label: 'advanced options',        desc: 'Advanced diagnostics and guided repair utilities' },
  { id: 15, label: 'chkdsk NTFS fix - beta',  desc: 'Full Linux chkdsk-style kit: multi-pass fix, dirty/hiber clear, mount verify' },
  { id: 16, label: 'dd fix bad blocks',       desc: 'Guided low-level block overwrite for specific bad sectors (DANGEROUS)' },
  { id: 17, label: 'force mount',             desc: 'FORCE mount NTFS (data loss assumed; overwrites / aggressive force)' },
];

const STATUS_BAR_LENGTH = 60;
const KEY_IMAGE_PATH = path.join(APP_DIR, 'redkeys.png');
const DEPS_DIR = path.join(APP_DIR, 'deps');
const DEPS_BIN_DIR = path.join(DEPS_DIR, 'usr', 'bin');
const DEPS_ENV_SCRIPT = path.join(DEPS_DIR, 'env.sh');

// Key image geometry. The source image (redkeys.png) is 2:1. A terminal cell is about
// twice as tall as it is wide, so 70 columns x 18 rows is shown as a ~2:1 picture
// ("70x35" in half-block pixels). It is scaled down automatically on small terminals.
const KEY_IMG_COLS = 70;
const KEY_IMG_ROWS = 18;
const KEY_IMG_MIN_ROWS = 8;        // below this the image is hidden instead of drawn tiny
const KEY_IMG_ROWS_RESERVED = 30;  // rows needed by title + info lines + the 18-row menu

// ============================================
// STATE MANAGEMENT (resets on restart)
// ============================================

let sessionState = {
  selectedOption: null,
  optionStatus: {},      // { [id]: { done, marker, color } }
  initialMarkers: {},    // { [id]: markerChar }
  selectedVolumes: [],
  selectedVolumeDetails: {}, // path -> { path, size, model, label, diskModel, diskSize, vendor }
  sessionCount: 0,
  lastCompletedOption: null,
  mountingErrorsOutput: '',
  showMountingErrors: false, // persistent in menu after first run until re-run refreshes
};

// ---------------------------------------------------------------------------
// Key image (static-chafa)
//
// BUG THAT USED TO MAKE THE APP EXIT SILENTLY ~2 SECONDS AFTER START:
// `new Chafa()` without arguments, on a TTY, starts an asynchronous terminal probe: it
// takes over stdin for ~300 ms (raw mode + escape-sequence queries) and, when it ends,
// calls stdin.pause(). If that happens after inquirer has opened the main-menu prompt,
// stdin is left paused, the Node event loop becomes empty and the process quits with
// exit code 0 and no message. The probe is skipped ONLY when pixelMode, cellW and cellH
// are ALL passed explicitly, so we always pass all three.
// pixelMode SYMBOLS additionally forces plain text blocks; otherwise the library
// auto-selects kitty/sixel/iTerm2 graphics on kitty, Konsole, WezTerm, Ghostty, ...
// which would corrupt the text layout of the menus.
// ---------------------------------------------------------------------------
let chafaLib = null;
let chafaLoadError = null;
try {
  chafaLib = require('static-chafa');
} catch (e) {
  chafaLoadError = e; // e.g. no prebuilt binary for this platform: run without the image
}

let chafaInstance = null;
function getChafa() {
  if (chafaInstance || !chafaLib) return chafaInstance;
  try {
    const { Chafa, PixelMode, ColorSpace, DitherMode, CanvasMode, ColorExtractor } = chafaLib;
    // Quality-first config: same cell geometry (KEY_IMG_COLS x KEY_IMG_ROWS) keeps
    // proportions/aspect ratio identical to the main menu layout. workFactor=1,
    // diffusion dither, DIN99d color space and preprocessing maximize color depth.
    chafaInstance = new Chafa({
      termW: KEY_IMG_COLS,
      termH: KEY_IMG_ROWS,
      pixelMode: PixelMode.SYMBOLS, // text only (avoids kitty/sixel layout corruption)
      cellW: 8,                     // explicit => no terminal probe / stdin pause
      cellH: 16,
      canvasMode: CanvasMode.TRUECOLOR,
      symbols: 'all',
      fillSymbols: 'block+solid+space',
      colorSpace: ColorSpace.DIN99D,
      colorExtractor: ColorExtractor.MEDIAN,
      ditherMode: DitherMode.DIFFUSION,
      workFactor: 1.0,
      preprocessing: 1,
      fgOnly: 0,
      tuned: 0,
    });
  } catch (e) {
    chafaLoadError = e;
    chafaInstance = null;
  }
  return chafaInstance;
}

const keyImageCache = new Map();
let titleCache = null;

function getTitleText() {
  if (titleCache === null) {
    try {
      titleCache = figlet.textSync('NTFS-REPAIR', { font: 'Small', horizontalLayout: 'fitted' });
    } catch (_) {
      titleCache = 'NTFS-REPAIR';
    }
  }
  return titleCache;
}

// ============================================
// COLOR HELPERS
// ============================================

const colors = {
  keyRed: chalk.hex('#FF0000'),
  keyOrange: chalk.hex('#FF8C00'),
  arrowGreen: chalk.hex('#00FF00'),
  dashYellow: chalk.hex('#FFFF00'),
  dashOrange: chalk.hex('#FF8C00'),
  hashGray: chalk.hex('#808080'),
  bracketWhite: chalk.hex('#FFFFFF'),
  bracketYellow: chalk.hex('#FFFF00'),
  starCyan: chalk.hex('#00FFFF'),
  optionLabel: chalk.hex('#FFFFFF'),
  optionDesc: chalk.hex('#888888'),
  optionNumber: chalk.hex('#00FFFF'),
  selectedOption: chalk.hex('#FFD700'),
  completedOption: chalk.hex('#00FF00'),
  title: gradient(['#FF0000', '#FF8C00', '#FFFF00']),
  subtitle: chalk.hex('#888888'),
  border: chalk.hex('#444444'),
  warning: chalk.hex('#FFAA00'),
  danger: chalk.hex('#FF4444'),
  success: chalk.hex('#00FF00'),
  info: chalk.hex('#00FFFF'),
  volumeSelected: chalk.hex('#00FF00'),
  volumeUnselected: chalk.hex('#888888'),
  dim: chalk.hex('#666666'),
};

const markerColors = [
  chalk.hex('#FF0000'),   // Red
  chalk.hex('#FF8C00'),   // Orange
  chalk.hex('#FFFF00'),   // Yellow
  chalk.hex('#00FF00'),   // Green
  chalk.hex('#00FFFF'),   // Cyan
  chalk.hex('#0088FF'),   // Blue-ish
  chalk.hex('#FF00FF'),   // Magenta
  chalk.hex('#FFFFFF'),   // White
  chalk.hex('#FF6B6B'),   // Light red
  chalk.hex('#B388FF'),   // Purple
  chalk.hex('#00FF7F'),   // SpringGreen
  chalk.hex('#FF1493'),   // DeepPink
  chalk.hex('#1E90FF'),   // DodgerBlue
  chalk.hex('#FFD700'),   // Gold
  chalk.hex('#ADFF2F'),   // GreenYellow
];

function getRandomMarker() {
  return MARKER_POOL[Math.floor(Math.random() * MARKER_POOL.length)];
}

function getRandomMarkerColor() {
  return markerColors[Math.floor(Math.random() * markerColors.length)];
}

function initializeMarkers() {
  if (Object.keys(sessionState.initialMarkers).length === 0) {
    MENU_OPTIONS.forEach(opt => {
      sessionState.initialMarkers[opt.id] = getRandomMarker();
    });
  }
}

// ============================================
// UTILITIES
// ============================================

function clearScreen() {
  // Hard clear so previous menu/option text cannot bleed into the next screen
  // (esp. after option 4 mounting-errors result -> main menu).
  try {
    process.stdout.write('\x1b[?25l');   // hide cursor while clearing
    process.stdout.write('\x1b[?1049l'); // leave alternate screen buffer
    process.stdout.write('\x1b[0m');     // reset all attributes
    process.stdout.write('\x1bc');      // RIS full reset (many terminals)
    process.stdout.write('\x1b[2J');     // erase entire screen
    process.stdout.write('\x1b[3J');     // erase scrollback
    process.stdout.write('\x1b[H');      // cursor to 1;1
    process.stdout.write('\x1b[0J');     // erase down from cursor
    if (typeof process.stdout.cursorTo === 'function') process.stdout.cursorTo(0, 0);
    if (typeof process.stdout.clearScreenDown === 'function') process.stdout.clearScreenDown();
    if (typeof process.stdout.write === 'function' && process.stdout.isTTY) {
      try { process.stdout.write(''); } catch (_) {}
    }
    process.stdout.write('\x1b[?25h');   // show cursor
  } catch (_) {
    try { process.stdout.write('\x1b[2J\x1b[3J\x1b[H\x1b[?25h'); } catch (__) {}
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function isRoot() {
  return !!(process.getuid && process.getuid() === 0);
}

function handlePromptError(err, context = 'operation') {
  if (err && err.code === 'ERR_USE_AFTER_CLOSE') {
    clearScreen();
    console.error(colors.danger(`\nTerminal input was closed during ${context}.`));
    console.error(colors.info('Please run NTFS-REPAIR directly in an interactive terminal.'));
    process.exit(1);
  }
  throw err;
}

async function safePrompt(questions, context = 'prompt') {
  try {
    return await inquirer.prompt(questions);
  } catch (err) {
    handlePromptError(err, context);
  }
}

// Quote a value so the shell receives it as ONE literal word (paths with spaces,
// quotes, $ ... are safe). Always use it when putting a path/device into a command.
function shq(value) {
  return "'" + String(value).replace(/'/g, "'\\''") + "'";
}

const SBIN_DIRS = ['/usr/local/sbin', '/usr/sbin', '/sbin'];
const SHELL = (fs.existsSync('/bin/bash') || fs.existsSync('/usr/bin/bash')) ? 'bash' : 'sh';
const toolCache = new Map();

function searchPathDirs() {
  const fromEnv = String(process.env.PATH || '').split(':').filter(Boolean);
  // local ./deps build first, then the environment PATH, then the usual (s)bin dirs
  // (a non-root shell often lacks /sbin and /usr/sbin).
  return [...new Set([DEPS_BIN_DIR, ...fromEnv, '/usr/local/bin', '/usr/bin', '/bin', ...SBIN_DIRS])];
}

// Pure-JS replacement for `bash -lc "command -v X"`: no login shell is spawned (that was
// slow, spawned dozens of times and could print junk from profile scripts) and nothing
// is interpolated into a shell command line.
function findExecutable(name) {
  if (toolCache.has(name)) return toolCache.get(name);
  let found = null;
  for (const dir of searchPathDirs()) {
    const candidate = path.join(dir, name);
    try {
      if (fs.statSync(candidate).isFile()) {
        fs.accessSync(candidate, fs.constants.X_OK);
        found = candidate;
        break;
      }
    } catch (_) { /* not in this directory */ }
  }
  toolCache.set(name, found);
  return found;
}

function commandExists(cmd) {
  return !!findExecutable(cmd);
}

function resolveToolPath(tool) {
  return findExecutable(tool) || tool;
}

// Environment for every child process: complete PATH + libs of the local ./deps build.
function toolEnv() {
  const env = { ...process.env, PATH: searchPathDirs().join(':') };
  const libDirs = ['lib', 'lib64'].map(d => path.join(DEPS_DIR, 'usr', d)).filter(d => fs.existsSync(d));
  if (libDirs.length) {
    env.LD_LIBRARY_PATH = [...libDirs, process.env.LD_LIBRARY_PATH].filter(Boolean).join(':');
  }
  return env;
}

// Synchronous runner: only for short commands. Long/unknown-duration commands must use
// runCommandAsync() so the progress animation keeps running.
function runCommandCapture(cmd, opts = {}) {
  const timeout = opts.timeout ?? 30000;
  const maxBuffer = opts.maxBuffer ?? 4 * 1024 * 1024;
  const r = spawnSync(SHELL, ['-c', cmd], {
    encoding: 'utf8',
    timeout,
    maxBuffer,
    env: toolEnv(),
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  const stdout = r.stdout ? String(r.stdout) : '';
  const stderr = r.stderr ? String(r.stderr) : '';
  let extra = '';
  if (r.error) {
    extra = r.error.code === 'ETIMEDOUT' ? `[Timed out after ${timeout}ms]` : String(r.error.message || r.error);
  }
  const code = typeof r.status === 'number' ? r.status : -1;
  return { code, stdout, stderr, output: [stdout, stderr, extra].filter(Boolean).join('\n') };
}

// Asynchronous runner (stdout+stderr merged, in order). Never blocks the event loop.
function runCommandAsync(cmd, opts = {}) {
  const timeout = opts.timeout ?? 30000;
  const maxBuffer = opts.maxBuffer ?? 8 * 1024 * 1024;
  return new Promise((resolve) => {
    let out = '';
    let finished = false;
    let timedOut = false;
    let child;
    const finish = (code) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      if (timedOut) out += `\n[Timed out after ${timeout}ms]`;
      resolve({ code: timedOut ? -1 : (code ?? -1), stdout: out, stderr: '', output: out });
    };
    const timer = setTimeout(() => {
      timedOut = true;
      try { child && child.kill('SIGKILL'); } catch (_) {}
    }, timeout);
    try {
      child = spawn(SHELL, ['-c', cmd], { stdio: ['ignore', 'pipe', 'pipe'], env: toolEnv() });
    } catch (e) {
      out = String((e && e.message) || e);
      return finish(-1);
    }
    const onData = (d) => { if (out.length < maxBuffer) out += d.toString(); };
    child.stdout.on('data', onData);
    child.stderr.on('data', onData);
    child.on('error', (e) => { out += '\n' + String((e && e.message) || e); finish(-1); });
    child.on('close', (code) => finish(code));
  });
}

// `ntfsinfo -m <volume>` (first <lines> lines), or a friendly message when not installed.
function ntfsinfoCmd(volume, lines = 60) {
  if (!commandExists('ntfsinfo')) return 'echo "ntfsinfo does not exist / not available"';
  return `${shq(resolveToolPath('ntfsinfo'))} -m ${shq(volume)} 2>&1 | head -${lines}`;
}

function isReadOnlyOptions(options) {
  // matches the "ro" mount option only (NOT "errors=remount-ro", "uid=..." etc.)
  return /(^|,)ro(,|$)/.test(String(options || ''));
}

function truncate(text, max) {
  const t = String(text);
  if (max <= 0) return '';
  return t.length <= max ? t : t.slice(0, Math.max(0, max - 1)) + '…';
}

function termCols() {
  return process.stdout.columns || 100;
}

function formatBox(title, body, borderColor = 'cyan') {
  return boxen(
    (title ? colors.title(title) + '\n\n' : '') + body,
    { padding: 1, margin: 1, borderStyle: 'round', borderColor }
  );
}

function hr(width = 70, ch = '─') {
  return colors.border(ch.repeat(Math.max(10, width)));
}

// ============================================
// IMAGE / HEADER RENDERING
// ============================================

// Size of the key image for the current terminal (null = do not show it).
function computeKeyImageSize() {
  const cols = process.stdout.columns || 80;
  const rows = process.stdout.rows || 40;
  const scale = Math.min(1, (cols - 2) / KEY_IMG_COLS, (rows - KEY_IMG_ROWS_RESERVED) / KEY_IMG_ROWS);
  if (!(scale > 0)) return null;
  const outRows = Math.round(KEY_IMG_ROWS * scale);
  if (outRows < KEY_IMG_MIN_ROWS) return null;
  return { cols: Math.max(10, Math.floor(KEY_IMG_COLS * scale)), rows: outRows };
}

// Rendered once per size and cached: it used to be re-decoded (735 KB PNG) on every
// single frame of every progress animation.
async function getKeyImageLines() {
  const size = computeKeyImageSize();
  if (!size) return [];
  const chafa = getChafa();
  if (!chafa) return [];
  const key = `${size.cols}x${size.rows}`;
  if (keyImageCache.has(key)) return keyImageCache.get(key);
  let lines;
  try {
    if (!fs.existsSync(KEY_IMAGE_PATH)) {
      lines = [colors.warning('[Key image does not exist: ' + KEY_IMAGE_PATH + ']')];
    } else {
      chafa.updateConfig({ termW: size.cols, termH: size.rows });
      const result = chafa.render(fs.readFileSync(KEY_IMAGE_PATH));
      lines = String(result.ansi || '').split('\n');
      while (lines.length && !lines[lines.length - 1].trim()) lines.pop();
    }
  } catch (e) {
    lines = [colors.warning('[Key Image Error] ' + (e && e.message ? e.message : String(e)))];
  }
  keyImageCache.set(key, lines);
  return lines;
}

async function drawHeader({ showVolumes = true, showMountingErrors = true } = {}) {
  initializeMarkers();
  console.log(colors.title(getTitleText()));
  console.log('');
  const imageLines = await getKeyImageLines();
  if (imageLines.length) {
    imageLines.forEach(line => console.log(line));
    console.log('');
  }

  if (showVolumes) {
    if (sessionState.selectedVolumes.length > 0) {
      const parts = sessionState.selectedVolumes.map(path => {
        const d = sessionState.selectedVolumeDetails[path] || {};
        const company = d.company || d.diskModel || d.model || '';
        const label = d.label ? ` "${d.label}"` : '';
        const size = d.size ? ` ${d.size}` : '';
        if (company) return `${path} (${company}${label}${size})`;
        return path + (label || size ? ` (${(label + size).trim()})` : '');
      });
      console.log(colors.volumeSelected('Selected volumes: ') + colors.info(parts.join(', ')));
    } else {
      console.log(colors.warning('Selected volumes: ') + colors.dim('(none) - use option 1 to select'));
    }
  }

  if (showMountingErrors && sessionState.showMountingErrors) {
    // Do NOT dump the full option-4 report here — it flooded the main menu and
    // visually replaced title / key image / selected volumes. One-line notice only.
    console.log('');
    console.log(colors.info('Mounting errors check (option 4): ') +
      colors.dim('last report kept — re-run option 4 to refresh; full text was shown after the check.'));
  }

  console.log('');
  console.log(hr(72));
}

async function drawFullInterface(options = {}) {
  clearScreen();
  await sleep(20);
  clearScreen();
  await drawHeader(options);
}

// ============================================
// VOLUME DETECTION / SELECTION
// ============================================

function getNTFSVolumes() {
  const volumes = [];
  function fmtSize(bytes) {
    const n = Number(bytes);
    if (!isFinite(n) || n <= 0) return 'Unknown';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0, v = n;
    while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
    return (i === 0 ? String(v) : v.toFixed(1)) + units[i];
  }

  try {
    // Include VENDOR + MODEL so we can show company/disk name (usually on parent disk)
    const r = runCommandCapture(
      "lsblk -J -b -o NAME,PATH,FSTYPE,SIZE,MOUNTPOINT,MOUNTPOINTS,RO,MODEL,VENDOR,LABEL,UUID,TYPE,TRAN 2>/dev/null || " +
      "lsblk -J -b -o NAME,PATH,FSTYPE,SIZE,MOUNTPOINT,RO,MODEL,LABEL,UUID,TYPE 2>/dev/null",
      { timeout: 12000 }
    );
    const data = JSON.parse(r.stdout);

    function traverse(blockDevices, parentCtx) {
      if (!blockDevices) return;
      for (const dev of blockDevices) {
        const vendor = (dev.vendor || '').trim();
        const model = (dev.model || '').trim();
        const ctx = {
          diskModel: model || (parentCtx && parentCtx.diskModel) || '',
          diskVendor: vendor || (parentCtx && parentCtx.diskVendor) || '',
          diskSize: (dev.type === 'disk' && dev.size) ? fmtSize(dev.size)
            : (parentCtx && parentCtx.diskSize) || '',
          diskName: (dev.type === 'disk' ? (dev.name || '') : (parentCtx && parentCtx.diskName) || ''),
          diskPath: (dev.type === 'disk' ? (dev.path || ('/dev/' + (dev.name || ''))) : (parentCtx && parentCtx.diskPath) || ''),
          transport: (dev.tran || (parentCtx && parentCtx.transport) || ''),
        };
        // Prefer combined company name: "Vendor Model"
        const company = [ctx.diskVendor, ctx.diskModel].filter(Boolean).join(' ').trim()
          || ctx.diskModel || ctx.diskVendor || '';

        if (String(dev.fstype || '').toLowerCase() === 'ntfs') {
          const devPath = dev.path || ('/dev/' + dev.name);
          const mp = dev.mountpoint
            || (Array.isArray(dev.mountpoints) ? (dev.mountpoints.filter(Boolean)[0] || '') : (dev.mountpoints || ''))
            || 'not mounted';
          volumes.push({
            path: devPath,
            name: dev.name || devPath,
            size: fmtSize(dev.size),
            sizeBytes: Number(dev.size) || 0,
            mountpoint: mp,
            ro: (dev.ro === true || dev.ro === '1' || dev.ro === 1) ? 'ro' : 'rw',
            model: model || ctx.diskModel || '',
            vendor: vendor || ctx.diskVendor || '',
            company: company || 'Unknown disk',
            diskModel: ctx.diskModel || '',
            diskVendor: ctx.diskVendor || '',
            diskSize: ctx.diskSize || fmtSize(dev.size),
            diskName: ctx.diskName || '',
            diskPath: ctx.diskPath || '',
            transport: ctx.transport || '',
            label: (dev.label || '').trim(),
            uuid: dev.uuid || '',
            selected: sessionState.selectedVolumes.includes(devPath),
          });
        }
        if (dev.children) traverse(dev.children, ctx);
      }
    }
    traverse(data.blockdevices, null);
  } catch (e) {
    try {
      const output = runCommandCapture("blkid -t TYPE=ntfs -o device 2>/dev/null", { timeout: 10000 }).stdout;
      output.trim().split('\n').filter(Boolean).forEach(p => {
        const devPath = p.trim();
        // Enrich from lsblk single device if possible
        let company = '', size = 'Unknown', label = '', model = '';
        try {
          const one = runCommandCapture(
            `lsblk -n -b -o SIZE,MODEL,VENDOR,LABEL,TYPE ${devPath.replace(/[^a-zA-Z0-9/_\-]/g, '')} 2>/dev/null; ` +
            `lsblk -n -b -o SIZE,MODEL,VENDOR -d $(lsblk -n -o PKNAME ${devPath.replace(/[^a-zA-Z0-9/_\-]/g, '')} 2>/dev/null | head -1 | sed 's|^|/dev/|') 2>/dev/null`,
            { timeout: 5000 }
          ).stdout.trim();
          // best-effort parse ignored if empty
        } catch (_) {}
        volumes.push({
          path: devPath,
          name: devPath.replace('/dev/', ''),
          size,
          sizeBytes: 0,
          mountpoint: 'Unknown',
          ro: '?',
          model,
          vendor: '',
          company: company || 'Unknown disk',
          diskModel: model,
          diskVendor: '',
          diskSize: size,
          diskName: '',
          diskPath: '',
          transport: '',
          label,
          uuid: '',
          selected: sessionState.selectedVolumes.includes(devPath),
        });
      });
    } catch (_) {}
  }
  return volumes;
}

// ---- progress bar --------------------------------------------------------
// The header (title + image + info) is drawn ONCE; only the 3 progress lines are redrawn
// in place. Previously the whole screen (including the image) was cleared and re-rendered
// every 120 ms, which flickered badly and re-decoded the PNG on every frame.
const PROGRESS_LINES = 3; // blank line + bar line + hint line

function buildProgressBar(position, { done = false } = {}) {
  const frames = STATUS_BAR_LENGTH;
  const open = colors.bracketYellow('[');
  const close = colors.bracketYellow(']');
  if (done) return open + colors.starCyan('*'.repeat(frames)) + close;
  // Animation: [$####...] -> [>$###...] -> [->$##...] -> [-------------->$]
  // '>' always immediately before '$'. When arrowPos == maxPos, the head replaces
  // the last '#' so the bar is fully filled: [----------------------------->$]
  const headLen = 2; // '>' + '$'
  const maxPos = Math.max(0, frames - headLen);
  const arrowPos = Math.min(Math.max(0, position), maxPos);
  const dashes = colors.dashOrange('-'.repeat(arrowPos));
  const head = colors.arrowGreen('>') + colors.keyRed('$');
  const hashes = colors.hashGray('#'.repeat(Math.max(0, frames - arrowPos - headLen)));
  return open + dashes + head + hashes + close;
}

/** Inclusive max head position so the bar can replace the final '#'. */
function progressMaxPos() {
  return Math.max(0, STATUS_BAR_LENGTH - 2);
}

// Draws one progress frame. With rewind=true the previous frame is erased first; erase +
// redraw go out in ONE write so the terminal never shows the empty gap in between.
function drawProgressFrame(bar, label, hint = '', rewind = false) {
  // Keep every line shorter than the terminal width, otherwise the line wraps and the
  // "rewind PROGRESS_LINES lines" below would leave garbage on screen.
  const room = termCols() - (STATUS_BAR_LENGTH + 2) - 5;
  process.stdout.write(
    (rewind ? `\x1b[${PROGRESS_LINES}A\x1b[0J` : '') +
    '\n  ' + bar + '  ' + colors.info(truncate(label, room)) + '\n' +
    (hint ? colors.dim('  ' + truncate(hint, termCols() - 4)) : '') + '\n'
  );
}

// Runs `work()` (must return a Promise and must NOT block the event loop) while an
// animated progress bar is shown. Returns the value produced by `work`.
async function runWithProgress(label, work, { hint = 'Working... please wait', showMountingErrors = false } = {}) {
  clearScreen();
  await drawHeader({ showVolumes: true, showMountingErrors: false });
  let finished = false;
  let value;
  let error = null;
  const task = Promise.resolve()
    .then(work)
    .then((v) => { value = v; }, (e) => { error = e; })
    .then(() => { finished = true; });
  let i = 0;
  let drawn = false;
  while (!finished) {
    drawProgressFrame(buildProgressBar(i % (progressMaxPos() + 1)), label, hint, drawn);
    drawn = true;
    await Promise.race([sleep(120), task]);
    i++;
  }
  await task;
  drawProgressFrame(buildProgressBar(0, { done: true }), label, '', drawn);
  await sleep(3000); // cyan stars hold 3 seconds before bar disappears
  if (error) throw error;
  return value;
}

async function animateProgress(label, duration = 1200) {
  const maxPos = progressMaxPos();
  const steps = maxPos + 1; // 0 .. maxPos inclusive so last '#' is replaced
  const frameDuration = Math.max(20, Math.floor(duration / steps));
  clearScreen();
  await drawHeader({ showVolumes: true, showMountingErrors: false });
  for (let i = 0; i <= maxPos; i++) {
    drawProgressFrame(buildProgressBar(i), label, '', i > 0);
    await sleep(frameDuration);
  }
  // Final frame: head has replaced the last '#', then cyan stars for 3s
  drawProgressFrame(buildProgressBar(0, { done: true }), label, '', true);
  await sleep(3000);
}

async function selectVolumesMenu() {
  await animateProgress('Detecting NTFS volumes...', 1200);
  const volumes = getNTFSVolumes();
  clearScreen();
  await drawHeader({ showVolumes: true, showMountingErrors: false });
  console.log('\n' + colors.title('SELECT NTFS VOLUME(S)'));
  console.log(colors.subtitle('SPACE = tick/untick a volume, ENTER = confirm. Multiple volumes supported.\n'));

  if (volumes.length === 0) {
    console.log(colors.warning('No NTFS volumes detected. (does not exist / none found)'));
    console.log(colors.dim('Tips: run as root (sudo), ensure disks are connected, and NTFS partitions exist.'));
    console.log('');
    await safePrompt([{ type: 'input', name: 'continue', message: colors.subtitle('Press ENTER to return...') }], 'volume selection (no volumes)');
    return { changed: false };
  }

  const infoRoom = termCols() - 10;
  const choices = volumes.map(v => {
    // Rich line: path | partition size | company/disk | volume label | mount | ro
    const company = v.company || [v.vendor, v.model || v.diskModel].filter(Boolean).join(' ').trim() || 'Unknown disk';
    const diskSz = v.diskSize && v.diskSize !== v.size ? ` disk ${v.diskSize}` : '';
    const volLabel = v.label ? `label="${v.label}"` : '';
    const tran = v.transport ? v.transport : '';
    const bits = [
      v.path.padEnd(12),
      String(v.size || '?').padEnd(7),
      company.slice(0, 28),
      diskSz,
      volLabel,
      String(v.mountpoint || '').slice(0, 14),
      v.ro,
      tran,
    ].filter(Boolean).join('  ');
    return { name: colors.optionNumber(truncate(bits, infoRoom)), value: v.path, checked: v.selected };
  });
  // Cache details for main-menu display after confirm
  sessionState._volumeCatalog = {};
  volumes.forEach(v => { sessionState._volumeCatalog[v.path] = v; });
  choices.push(new inquirer.Separator());
  // Last option confirms the selection. Must be reachable with arrow keys (pageSize large enough).
  choices.push({ name: colors.warning('← Back (keep current selection)'), value: '__back__' });

  // Confirmation rule:
  // - Tick volume(s) with SPACE.
  // - Navigate to "Back (keep current selection)", tick it with SPACE, then press ENTER
  //   to confirm. Selected volumes are only applied when "__back__" is among the checked
  //   items. This makes the last option the explicit confirmation step.
  // - If ENTER is pressed without "__back__" checked, re-prompt with a clear message
  //   so volumes are not silently dropped and the user can still reach the last option.
  let confirmed = false;
  let picked = [];
  while (!confirmed) {
    const ans = await safePrompt([{
      type: 'checkbox',
      name: 'picked',
      message: colors.info('Select NTFS volumes (SPACE to tick volumes + Back, ENTER to confirm):'),
      choices,
      pageSize: Math.max(20, choices.length + 2),
      loop: true,
    }], 'volume selection');

    picked = (ans && ans.picked) || [];
    if (picked.includes('__back__')) {
      confirmed = true;
      break;
    }
    console.log(colors.warning('\n  To confirm, also tick "← Back (keep current selection)" then press ENTER.'));
    console.log(colors.dim('  (Or tick Back alone to keep the previous selection and return.)\n'));
    // Preserve ticks for the next prompt
    choices.forEach(c => {
      if (c && typeof c === 'object' && 'value' in c && c.value !== undefined) {
        c.checked = picked.includes(c.value);
      }
    });
  }

  const volumesPicked = picked.filter(x => !String(x).startsWith('__'));
  // Back alone = keep current selection unchanged
  if (volumesPicked.length === 0 && picked.includes('__back__')) {
    return { changed: false };
  }
  sessionState.selectedVolumes = volumesPicked;
  const catalog = sessionState._volumeCatalog || {};
  const details = {};
  volumesPicked.forEach(path => {
    const v = catalog[path] || { path };
    details[path] = {
      path,
      size: v.size || '',
      label: v.label || '',
      company: v.company || v.diskModel || v.model || '',
      model: v.model || v.diskModel || '',
      vendor: v.vendor || v.diskVendor || '',
      diskSize: v.diskSize || '',
      diskName: v.diskName || '',
      transport: v.transport || '',
    };
  });
  sessionState.selectedVolumeDetails = details;
  return { changed: true };
}

// ============================================
// RESULT / OUTPUT DISPLAY
// ============================================

function printOutputBlock(text) {
  const lines = String(text || '').replace(/\r\n/g, '\n').split('\n');
  if (lines.length === 0) {
    console.log(colors.dim('(no output)'));
    return;
  }
  for (const line of lines) {
    if (/^===|^--- SUMMARY ---/.test(line)) console.log(colors.info(line));
    else if (/^--- /.test(line)) console.log(colors.optionLabel(line));
    else if (/error|fail|corrupt|dirty|denied|invalid|cannot|unable|refused|not found|unsupported|warning/i.test(line)) console.log(colors.warning(line));
    else if (/success|ok|clean|fixed|completed|no errors/i.test(line)) console.log(colors.success(line));
    else console.log(colors.optionDesc(line));
  }
}

async function showResultScreen({ title, summaryLines = [], output = '', status = 'info', wait = true }) {
  clearScreen();
  await drawHeader({ showVolumes: true, showMountingErrors: false });
  const color = status === 'success' ? 'green' : status === 'warning' ? 'yellow' : status === 'danger' ? 'red' : 'cyan';
  const icon = status === 'success' ? '✓' : status === 'warning' ? '⚠' : status === 'danger' ? '✗' : 'ℹ';
  const head = `${icon} ${title}`;
  const summary = summaryLines.length ? summaryLines.map(l => `• ${l}`).join('\n') : '';
  console.log(boxen((status === 'danger' ? colors.danger(head) : status === 'warning' ? colors.warning(head) : status === 'success' ? colors.success(head) : colors.info(head)) + (summary ? '\n\n' + colors.optionDesc(summary) : ''), { padding: 1, margin: 1, borderStyle: 'round', borderColor: color }));

  if (output && String(output).trim()) {
    console.log(colors.info('Output / Details:'));
    console.log(hr(72));
    printOutputBlock(output);
    console.log(hr(72));
  }

  if (wait) {
    await safePrompt([{ type: 'input', name: 'continue', message: colors.subtitle('Press ENTER to return to menu...') }], 'result screen');
  }
}

// ============================================
// SAFETY / CHECKS
// ============================================

function getMountInfo(volume) {
  const r = runCommandCapture(`findmnt -nr -o TARGET,FSTYPE,OPTIONS,SOURCE ${shq(volume)} 2>/dev/null`, { timeout: 8000 });
  const line = (r.output || '').trim();
  if (!line) return { mounted: false, raw: '', mountpoint: '', options: '' };
  const parts = line.split(/\s+/);
  return {
    mounted: true,
    raw: line,
    mountpoint: parts[0] || '',
    fstype: parts[1] || '',
    options: parts[2] || '',
  };
}

function ensureVolumeUnmountedForWrite(volume, operationLabel) {
  const mi = getMountInfo(volume);
  if (mi.mounted) {
    return {
      ok: false,
      reason: `${operationLabel} requires the volume to be unmounted. Currently mounted at "${mi.mountpoint}" (${mi.options}). Unmount it first (e.g. sudo umount ${volume}).`,
      mountInfo: mi,
    };
  }
  return { ok: true, mountInfo: mi };
}

function requireRootMessage() {
  if (isRoot()) return null;
  return 'Root privileges are required for most NTFS repair operations. Run with: sudo ntfs-repair (or sudo ksvn / sudo ntfsre-pair).';
}

// ============================================
// OPTION 4: MOUNTING ERRORS CHECK (IMPROVED)
// ============================================

// "$MFT", "$Bitmap", "$LogFile" are named in the output of every healthy ntfsfix/ntfsinfo run,
// so they only count when they appear together with an error word on the same line.
const INTEGRITY_RE = /(mft|bitmap|logfile)[^\n]*(corrupt|invalid|damaged|error|fail|inconsisten|mismatch)|(corrupt|invalid|damaged|error|fail|inconsisten|mismatch)[^\n]*(mft|bitmap|logfile)|corrupt|damaged|bad sector|i\/o error|input\/output error/;

function escapeRegExp(text) {
  return String(text).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// Keep the matching lines of a kernel/journal dump. If nothing matches but the dump
// itself is an error (e.g. dmesg "Operation not permitted"), show that error instead of
// pretending there are simply no entries.
function filterLogLines(raw, re, emptyMessage, max = 40) {
  const text = String(raw || '');
  const hits = text.split('\n').filter(l => re.test(l)).slice(-max);
  if (hits.length) return hits.join('\n');
  if (/not permitted|permission denied|read kernel buffer failed|command not found|no such file/i.test(text)) {
    return text.trim().split('\n').slice(0, 3).join('\n');
  }
  return emptyMessage;
}

// NOTE: this function is async and uses runCommandAsync(), so the progress animation keeps
// running. It used to call execSync() up to 12 times (15 s timeout each) which froze the
// whole UI while it ran.
async function checkMountingErrorsForVolume(volume) {
  const v = shq(volume);
  const shortName = volume.replace('/dev/', '');
  const ts = new Date().toISOString();
  const ntfsfix = shq(resolveToolPath('ntfsfix'));
  const devRe = new RegExp('ntfs|' + escapeRegExp(shortName), 'i');
  const errRe = /error|fail|corrupt|dirty|read[- ]?only|denied|invalid|cannot|unable|refus|mount|i\/o|input\/output|bad sector|mft|bitmap|logfile|unmounted|recover/i;

  const dmesgRaw = (await runCommandAsync('dmesg -T 2>&1', { timeout: 15000 })).output;
  const journalRaw = (await runCommandAsync('journalctl -k --no-pager -n 300 2>&1', { timeout: 15000 })).output;
  const probe = commandExists('ntfs-3g.probe')
    ? `${shq(resolveToolPath('ntfs-3g.probe'))} --readonly ${v} 2>&1; echo "PROBE_EXIT:$?"`
    : 'echo "ntfs-3g.probe not available"';

  const checks = [
    { label: 'Mount status (findmnt)', cmd: `findmnt -n -o TARGET,FSTYPE,OPTIONS,SOURCE ${v} 2>&1 || echo "NOT_MOUNTED"` },
    { label: 'Mount table (mount)', cmd: `mount 2>&1 | grep -E ${shq(volume + '|' + shortName)} || echo "NOT_IN_MOUNT_TABLE"` },
    { label: 'Block device info (lsblk)', cmd: `lsblk -o NAME,PATH,FSTYPE,SIZE,RO,MOUNTPOINTS,LABEL,UUID,MODEL ${v} 2>&1` },
    { label: 'Filesystem signature (blkid)', cmd: `blkid -o full ${v} 2>&1 || blkid ${v} 2>&1` },
    { label: 'Partition/filesystem state (ntfsfix -n)', cmd: `${ntfsfix} -n ${v} 2>&1 || echo "ntfsfix not available or failed"` },
    { label: 'NTFS metadata summary (ntfsinfo -m)', cmd: ntfsinfoCmd(volume, 60) },
    { label: 'NTFS-3G probe (readonly)', cmd: probe },
    { label: 'Kernel messages (dmesg, NTFS/device)', text: filterLogLines(dmesgRaw, devRe, 'No dmesg NTFS/device entries') },
    { label: 'Kernel errors/warnings (filtered)', text: filterLogLines(dmesgRaw, { test: (l) => devRe.test(l) && errRe.test(l) }, 'No filtered kernel errors/warnings') },
    { label: 'Journal (kernel, recent)', text: filterLogLines(journalRaw, devRe, 'No journal NTFS/device entries') },
    { label: 'fstab references', cmd: `grep -nE ${shq(volume + '|' + shortName)} /etc/fstab 2>&1 || echo "No fstab entry found"` },
    { label: 'Hibernation/Windows hints (ntfsfix -n scan text)', cmd: `${ntfsfix} -n ${v} 2>&1 | grep -i -E 'hiber|chkdsk|dirty|unclean|windows' || echo "(no hints found in ntfsfix output)"` },
  ];

  let out = '';
  out += `=== MOUNTING ERRORS CHECK ===\n`;
  out += `Volume: ${volume}\n`;
  out += `Timestamp: ${ts}\n\n`;

  const issues = [];
  const addIssue = (msg) => { if (msg && !issues.includes(msg)) issues.push(msg); };

  for (const check of checks) {
    const r = check.cmd ? await runCommandAsync(check.cmd, { timeout: 15000 }) : { output: check.text };
    const text = (r.output || '').trim() || '(no output)';
    out += `--- ${check.label} ---\n${text}\n\n`;

    const low = text.toLowerCase();
    if (check.label === 'Mount status (findmnt)') {
      if (text.includes('NOT_MOUNTED') || text === '(no output)') addIssue('Volume is not currently mounted.');
      if (text.split(/\s+/).some(isReadOnlyOptions) || /read-only/.test(low)) addIssue('Volume is mounted read-only (ro).');
    }
    if (/not_mounted|not_in_mount_table/.test(low) && /cannot|error|fail/.test(low)) addIssue(`${check.label}: mount-related errors reported.`);
    if (/dirty|unclean|chkdsk/.test(low)) addIssue('NTFS dirty/unclean state detected (Windows chkdsk or ntfsfix may be needed).');
    if (/hiber/.test(low)) addIssue('Hibernation/Fast Startup signature detected; Windows full shutdown/disable Fast Startup may be required.');
    if (INTEGRITY_RE.test(low)) addIssue(`${check.label}: filesystem/disk integrity issue indications found.`);
    if (/permission denied|operation not permitted/.test(low)) addIssue(`${check.label}: permission issue encountered (try running as root).`);
    if (/unknown filesystem type|wrong fs type/.test(low)) addIssue('Filesystem type/mount type issue reported.');
    if (/cannot mount/.test(low)) addIssue('Kernel/userspace reported a mount failure.');
  }

  out += `--- SUMMARY ---\n`;
  if (issues.length === 0) {
    out += `1. No obvious mounting errors detected by heuristics.\n`;
    out += `2. Review the detailed sections above for warnings, mount state, and kernel logs.\n`;
  } else {
    issues.forEach((iss, i) => { out += `${i + 1}. ${iss}\n`; });
  }
  out += `\n=== END OF CHECK ===`;
  return { output: out, issues };
}

// ============================================
// GENERIC VOLUME OPERATION RUNNERS
// ============================================

function collectVolumeListOrPrompt() {
  return [...sessionState.selectedVolumes];
}

async function runCommandWithProgress(label, cmd, timeout = 120000) {
  const r = await runWithProgress(label, () => runCommandAsync(cmd, { timeout }), { showMountingErrors: false });
  return { code: r.code, output: r.output };
}

async function executeVolumeOperation(optionId) {
  const volumes = collectVolumeListOrPrompt();
  if (volumes.length === 0) {
    await showResultScreen({
      title: 'No volumes selected',
      status: 'warning',
      summaryLines: ['Select at least one NTFS volume first (option 1).'],
      output: '',
    });
    return { completed: false, output: '' };
  }

  const rootMsg = requireRootMessage();
  if (rootMsg && [2,5,6,7,8,9,10,15,16,17].includes(optionId)) {
    // allow continuing but warn in output; some checks still useful
  }

  let combinedOutput = '';
  let overallStatus = 'success';
  const summary = [];

  if (optionId === 4) {
    // Fresh recheck: clear stale menu report during check
    sessionState.showMountingErrors = false;
    sessionState.mountingErrorsOutput = '';
  }

  for (const volume of volumes) {
    combinedOutput += `\n===== ${volume} =====\n`;
    if (!fs.existsSync(volume)) {
      combinedOutput += `Device does not exist: ${volume}\n`;
      overallStatus = overallStatus === 'danger' ? 'danger' : 'warning';
      summary.push(`${volume}: device does not exist`);
      if (optionId === 4) {
        combinedOutput += `--- SUMMARY ---\n1. Selected volume/device does not exist: ${volume}\n\n=== END OF CHECK ===\n`;
      }
      continue;
    }
    const mountInfo = getMountInfo(volume);

    if (optionId === 4) {
      // run diagnostics with progress UI per volume (async, UI stays animated)
      const label = `Checking mounting errors on ${volume}`;
      const result = await runWithProgress(label, () => checkMountingErrorsForVolume(volume), {
        hint: 'Collecting mount state, ntfsfix/ntfsinfo probes, dmesg, journal, fstab...',
        showMountingErrors: false,
      });
      combinedOutput += (result && result.output ? result.output : '(no output)') + '\n';
      if (result && result.issues && result.issues.length) overallStatus = 'warning';
      summary.push(`${volume}: ${result && result.issues && result.issues.length ? result.issues.length + ' issue(s) flagged' : 'no obvious issues flagged'}`);
      continue;
    }

    // For all other volume operations, do per-option behavior
    const op = await runSingleVolumeOperation(optionId, volume, mountInfo);
    combinedOutput += op.output + '\n';
    if (op.status === 'danger') overallStatus = 'danger';
    else if (op.status === 'warning' && overallStatus !== 'danger') overallStatus = 'warning';
    summary.push(`${volume}: ${op.summary}`);
  }

  // Store and display option 4 results immediately and persistently in menu
  if (optionId === 4) {
    sessionState.mountingErrorsOutput = combinedOutput.trim();
    sessionState.showMountingErrors = true;
    await showResultScreen({
      title: 'Mounting errors check complete',
      status: overallStatus === 'success' ? 'info' : overallStatus,
      summaryLines: [
        ...summary,
        'Full report is above. Main menu stays clean (one-line notice only).',
        'Re-run option 4 any time to refresh the report.',
      ],
      output: combinedOutput.trim(),
      wait: true,
    });
    return { completed: true, output: combinedOutput };
  }

  const labels = {
    2: 'Auto-fix completed',
    3: 'Filesystem integrity check completed',
    5: 'Read-only mount fix attempt completed',
    6: 'Bad blocks scan/fix completed',
    7: 'MFT repair/diagnostics completed',
    8: '$Bitmap repair attempt completed',
    9: '$LogFile fix attempt completed',
    10: 'Dirty flag clear attempt completed',
    15: 'chkdsk NTFS fix (beta) completed',
    16: 'DD bad-block operation completed',
    17: 'Force mount completed',
  };

  await showResultScreen({
    title: labels[optionId] || 'Operation completed',
    status: overallStatus,
    summaryLines: summary.length ? summary : ['Operation finished.'],
    output: combinedOutput.trim(),
  });
  return { completed: true, output: combinedOutput };
}

async function runSingleVolumeOperation(optionId, volume, mountInfo) {
  const ntfsfix = shq(resolveToolPath('ntfsfix'));
  const badblocks = shq(resolveToolPath('badblocks'));
  const vq = shq(volume);
  const ro = isReadOnlyOptions(mountInfo && mountInfo.options);
  let out = '';
  const append = (s='') => { out += String(s).replace(/\r\n/g, '\n') + (String(s).endsWith('\n') ? '' : '\n'); };
  append(`Volume: ${volume}`);
  append(`Mounted: ${mountInfo.mounted ? `yes (${mountInfo.mountpoint}, ${mountInfo.options})` : 'no'}`);
  append('');

  const needUnmountWarn = (op) => `Note: ${op} is safest on an unmounted volume.`;

  const run = async (label, cmd, timeout=120000) => {
    append(`$ ${cmd}`);
    const r = await runCommandWithProgress(`${label} (${volume})`, cmd, timeout);
    append(r.output && r.output.trim() ? r.output.trim() : '(no output)');
    append(`exit_code=${r.code}`);
    append('');
    return r;
  };

  if (optionId === 2) { // auto-fix — full safe automatic kit
    append('=== AUTO-FIX (safe automatic NTFS kit) ===');
    append('Sequence: offline if possible → diagnose → multi-pass ntfsfix → dirty/bad-sector clear →');
    append('hibernation cleanup → post-check → optional RO/RW verify.');
    append('');

    // Try unmount for write stages
    if (mountInfo.mounted) {
      append(needUnmountWarn('Auto-fix'));
      append('Attempting soft unmount...');
      const mp = mountInfo.mountpoint ? shq(mountInfo.mountpoint) : '';
      await runCommandAsync('sync', { timeout: 10000 });
      for (const c of [
        mp ? `umount ${mp} 2>&1` : null,
        `umount ${vq} 2>&1`,
        `umount -l ${vq} 2>&1`,
        `udisksctl unmount -b ${vq} 2>&1 || true`,
      ].filter(Boolean)) {
        const u = await runCommandAsync(c, { timeout: 15000 });
        if (u.output && u.output.trim()) append(u.output.trim());
        if (!getMountInfo(volume).mounted) break;
      }
      mountInfo = getMountInfo(volume);
      append(mountInfo.mounted ? 'Still mounted — write stages may be limited.' : 'Unmounted for auto-fix.');
      append('');
    }

    const r0 = await run('Auto-fix: diagnose (ntfsfix -n)', `${ntfsfix} -n ${vq}`);
    let codes = [r0.code];

    if (!getMountInfo(volume).mounted) {
      const r1 = await run('Auto-fix: primary ntfsfix pass', `${ntfsfix} ${vq}`);
      const r2 = await run('Auto-fix: clear dirty flag', `${ntfsfix} -d ${vq}`);
      const r3 = await run('Auto-fix: clear bad sectors list', `${ntfsfix} -b ${vq}`);
      const r4 = await run('Auto-fix: second ntfsfix pass', `${ntfsfix} ${vq}`);
      const r5 = await run('Auto-fix: dirty clear again', `${ntfsfix} -d ${vq}`);
      codes.push(r1.code, r2.code, r3.code, r4.code, r5.code);

      // Hibernation cleanup if ntfs-3g available
      const ntfs3gBin = resolveToolPath('ntfs-3g');
      if (ntfs3gBin && isRoot()) {
        const mp = fs.mkdtempSync(path.join(os.tmpdir(), 'ntfsrepair-autofix-'));
        const mq = shq(mp);
        const m = await run(
          'Auto-fix: mount remove_hiberfile',
          `${shq(ntfs3gBin)} -o remove_hiberfile,rw ${vq} ${mq} 2>&1; echo EC:$?`
        );
        codes.push(m.code);
        if (/EC:0/.test(m.output || '') || getMountInfo(volume).mounted) {
          const cl = await runCommandAsync(
            `rm -f ${mq}/hiberfil.sys ${mq}/Hiberfil.sys 2>&1; sync; umount ${mq} 2>&1 || umount -l ${mq} 2>&1 || true`,
            { timeout: 30000 }
          );
          append(cl.output || '');
        }
        try { fs.rmdirSync(mp); } catch (_) {}
        if (getMountInfo(volume).mounted) {
          await runCommandAsync(`umount ${vq} 2>&1 || umount -l ${vq} 2>&1 || true`, { timeout: 15000 });
        }
        const r6 = await run('Auto-fix: post-hiber ntfsfix -d', `${ntfsfix} -d ${vq}`);
        codes.push(r6.code);
      }
    } else {
      append('Write stages skipped (volume still mounted).');
    }

    const rN = await run('Auto-fix: post-check (ntfsfix -n)', `${ntfsfix} -n ${vq}`);
    codes.push(rN.code);

    // Quick mount verify if root
    let rwOk = false;
    if (isRoot() && !getMountInfo(volume).mounted) {
      const mp = fs.mkdtempSync(path.join(os.tmpdir(), 'ntfsrepair-afv-'));
      const mq = shq(mp);
      const ntfs3gBin = resolveToolPath('ntfs-3g');
      const cmd = ntfs3gBin
        ? `${shq(ntfs3gBin)} -o rw,remove_hiberfile ${vq} ${mq} 2>&1; echo EC:$?; touch ${mq}/.af_wtest 2>&1; echo W:$?; rm -f ${mq}/.af_wtest; umount ${mq} 2>&1 || true`
        : `mount -t ntfs3 -o rw ${vq} ${mq} 2>&1; echo EC:$?; umount ${mq} 2>&1 || true`;
      const v = await run('Auto-fix: RW mount verify', cmd);
      rwOk = /EC:0/.test(v.output || '') && /W:0/.test(v.output || '');
      try { fs.rmdirSync(mp); } catch (_) {}
    }

    const stillDirty = /dirty|unclean|hiber/i.test(rN.output || '');
    const status = (!stillDirty && (rwOk || codes.some(c => c === 0))) ? (stillDirty ? 'warning' : 'success') : 'warning';
    append('');
    append(`Auto-fix summary: codes=${codes.join(',')} dirty=${stillDirty} rwVerify=${rwOk}`);
    return { status, summary: `auto-fix done (dirty=${stillDirty}, rw=${rwOk})`, output: out };
  }

  if (optionId === 3) { // integrity check
    const r1 = await run('Integrity check: ntfsfix dry-run', `${ntfsfix} -n ${vq}`);
    const r2 = await run('Integrity check: ntfsinfo summary', ntfsinfoCmd(volume, 80));
    const issues = /error|corrupt|damaged|inconsisten|dirty|chkdsk/i.test((r1.output||'') + '\n' + (r2.output||''));
    return { status: issues ? 'warning' : 'success', summary: issues ? 'potential issues found in diagnostics' : 'no obvious issues reported', output: out };
  }

  if (optionId === 5) { // fix read-only mount
    if (mountInfo.mounted && !ro) append('Volume is currently mounted read-write; read-only fix may not be necessary.');
    if (mountInfo.mounted) append('If Windows Fast Startup/hibernation is enabled, fully shut down Windows (not restart) or disable Fast Startup, then retry.');
    const r1 = await run('Clear dirty flag / hibernation markers (ntfsfix -d)', `${ntfsfix} -d ${vq}`);
    const r2 = await run('Recheck state', `${ntfsfix} -n ${vq}`);
    if (mountInfo.mounted) {
      append('Mount remount hint (if appropriate):');
      append(`  sudo mount -o remount,rw ${mountInfo.mountpoint || volume}`);
    } else {
      append('Mount hint:');
      append(`  sudo mkdir -p /mnt/ntfs && sudo mount -t ntfs3 ${volume} /mnt/ntfs  (or ntfs-3g)`);
    }
    const status = r1.code === 0 ? (mountInfo.mounted ? 'warning' : 'success') : 'warning';
    return { status, summary: `read-only fix attempted (code ${r1.code})`, output: out };
  }

  if (optionId === 6) { // bad blocks scan/fix — best-effort kit comparable to Windows chkdsk / bad sector handling
    if (mountInfo.mounted) append(needUnmountWarn('Bad blocks scan'));
    append('=== Bad blocks kit (read-only scan + NTFS repair helpers) ===');
    append('Goal: detect bad sectors and apply safe NTFS fixes similar in spirit to Windows chkdsk / bad sector handling.');
    append('1) Read-only badblocks scan (non-destructive).');
    append('2) ntfsfix -b / -d style recovery to clear bad-sector lists and dirty state when tools allow.');
    append('3) Guidance for further steps (Windows chkdsk /C /R, SMART, hardware).');
    append('');
    // 1) Non-destructive surface scan
    const r1 = await run('Bad blocks read-only scan (badblocks -sv)', `${badblocks} -sv ${vq}`, 600000);
    const found = /bad blocks?/i.test(r1.output || '') && !/Pass completed, 0 bad blocks found/i.test(r1.output || '');
    // 2) Best-effort NTFS metadata / dirty / bad cluster list repair (safe flags)
    append('');
    append('--- NTFS repair helpers (ntfsfix) ---');
    const r2 = await run('ntfsfix -n (read-only check)', `${ntfsfix} -n ${vq}`, 120000);
    const r3 = await run('ntfsfix -b (clear bad sector list if supported)', `${ntfsfix} -b ${vq}`, 120000);
    const r4 = await run('ntfsfix -d (clear dirty flag)', `${ntfsfix} -d ${vq}`, 60000);
    append('');
    append('--- Guidance ---');
    if (found) {
      append('Bad blocks were reported by the scan.');
      append('Linux cannot always remap sectors the way Windows does; for full surface remapping:');
      append('  • Boot Windows and run: chkdsk X: /f /r   (or /scan /perf on newer Windows)');
      append('  • Check disk SMART health (smartctl -a).');
      append('  • Option 15 can guide targeted dd overwrite ONLY with backups and data-loss awareness.');
    } else {
      append('No bad blocks reported by the read-only scan (or scan incomplete/timeout).');
      append('If Windows still reports bad sectors, run chkdsk /f /r from Windows for cluster remapping.');
    }
    append('Always keep backups before any write-level repair.');
    const anyWarn = found || r1.code !== 0 || r3.code !== 0;
    return {
      status: anyWarn ? 'warning' : 'success',
      summary: found
        ? 'bad blocks reported — NTFS helpers run; prefer Windows chkdsk /r for remapping'
        : `bad-blocks kit finished (scan code ${r1.code}, ntfsfix -b ${r3.code})`,
      output: out,
    };
  }

  if (optionId === 7) { // repair MFT (best effort / diagnostics)
    append('ntfsfix provides limited repair capabilities; full MFT repair often requires Windows chkdsk.');
    const r1 = await run('Best-effort NTFS fix pass', `${ntfsfix} -d ${vq}`);
    const r2 = await run('MFT/volume metadata summary', ntfsinfoCmd(volume, 120));
    append('Recommended if corruption persists: run "chkdsk /f /r X:" from Windows on this volume.');
    const status = (r1.code === 0 ? 'warning' : 'warning');
    return { status, summary: 'MFT diagnostics/best-effort steps completed', output: out + (r2 ? '' : '') };
  }

  if (optionId === 8) { // rebuild $Bitmap (best effort)
    append('ntfsfix can clear the bad sector list (-b), which is related to cluster allocation tracking; full $Bitmap rebuild may require chkdsk.');
    const r1 = await run('Clear bad sectors list (ntfsfix -b)', `${ntfsfix} -b ${vq}`);
    const r2 = await run('Post-check', `${ntfsfix} -n ${vq}`);
    return { status: r1.code === 0 ? 'warning' : 'warning', summary: `bitmap-related fix attempted (code ${r1.code})`, output: out };
  }

  if (optionId === 9) { // fix $LogFile (best effort)
    append('ntfsfix can schedule/perform log replay and clear dirty state in common cases; it does not expose a separate standard -l flag on all builds.');
    const r1 = await run('Fix journal/log-related state (ntfsfix -d)', `${ntfsfix} -d ${vq}`);
    const r2 = await run('Post-check', `${ntfsfix} -n ${vq}`);
    append('If log corruption persists, back up data and run Windows chkdsk.');
    return { status: r1.code === 0 ? 'warning' : 'warning', summary: `$LogFile/dirty-state fix attempted (code ${r1.code})`, output: out };
  }

  if (optionId === 10) { // clear dirty flag
    const r1 = await run('Clear dirty flag', `${ntfsfix} -d ${vq}`);
    const r2 = await run('Post-check', `${ntfsfix} -n ${vq}`);
    return { status: r1.code === 0 ? 'success' : 'warning', summary: `dirty flag clear attempted (code ${r1.code})`, output: out };
  }

  if (optionId === 15) { // chkdsk NTFS fix - beta (Linux multi-phase kit)
    return await runChkdskNtfsBeta(volume, mountInfo, out);
  }

  if (optionId === 16) { // dd fix bad blocks (guided, targeted)
    return await runGuidedDdFix(volume, mountInfo, out);
  }

  if (optionId === 17) { // force mount — data loss assumed
    return await runForceMount(volume, mountInfo, out);
  }

  return { status: 'warning', summary: 'No operation implemented', output: out + 'No operation implemented for this option.\n' };
}


// ============================================
// chkdsk NTFS fix - beta (full Linux repair kit)
// Goal: make USB/NTFS usable on Linux without Windows whenever possible.
// Strategy mirrors Windows chkdsk phases as far as open tools allow:
//   force offline → diagnose → multi-pass ntfsfix → dirty/hiber clear →
//   bad-sector list → journal reset → mount with remove_hiberfile →
//   RW verify → optional recovery loops → post-check.
// ============================================
async function runChkdskNtfsBeta(volume, mountInfo, preface = '') {
  let out = preface || '';
  const append = (s = '') => { out += String(s).replace(/\r\n/g, '\n') + (String(s).endsWith('\n') ? '' : '\n'); };
  const ntfsfixBin = resolveToolPath('ntfsfix');
  const badblocksBin = resolveToolPath('badblocks');
  const ntfs3gBin = resolveToolPath('ntfs-3g');
  const ntfsfix = shq(ntfsfixBin);
  const badblocks = shq(badblocksBin);
  const vq = shq(volume);
  const shortName = volume.replace('/dev/', '');
  const diskBase = volume.replace(/[0-9]+$/, '').replace(/p$/, ''); // /dev/sdb1 -> /dev/sdb ; nvme0n1p1 careful

  append('╔══════════════════════════════════════════════════════════════════╗');
  append('║  chkdsk NTFS fix - beta  |  FULL Linux repair kit  v13.0.9       ║');
  append('║  Author: Svn DtkQdev                                             ║');
  append('║  Goal: fix NTFS/USB so it mounts RW without Windows              ║');
  append('╚══════════════════════════════════════════════════════════════════╝');
  append('');
  const det = sessionState.selectedVolumeDetails[volume] || {};
  if (det.company || det.size) {
    append(`Disk: ${det.company || '?'}  partition ${volume}  size ${det.size || '?'}  label ${det.label || '(none)'}`);
  }
  append(`Volume: ${volume}`);
  append(`Mounted: ${mountInfo.mounted ? 'YES at ' + (mountInfo.mountpoint || '?') + ' opts=' + (mountInfo.options || '') : 'no'}`);
  append(`Root: ${isRoot() ? 'yes' : 'NO — re-run with sudo for full repair'}`);
  append(`Tools: ntfsfix=${ntfsfixBin || 'MISSING'} ntfs-3g=${ntfs3gBin || 'MISSING'} badblocks=${badblocksBin || 'MISSING'}`);
  append('');

  async function stage(name, cmd, timeout = 120000) {
    append(`--- ${name} ---`);
    append(`$ ${cmd}`);
    const r = await runCommandWithProgress(name, cmd, timeout);
    append(r.output || '(no output)');
    append(`Exit code: ${r.code}`);
    append('');
    return r;
  }

  const isMounted = () => !!getMountInfo(volume).mounted;

  // ---- Stage 0: take device offline ----
  append('--- Stage 0: Take volume offline (force unmount) ---');
  await runCommandAsync('sync', { timeout: 15000 });
  if (mountInfo.mounted || isMounted()) {
    const mp = (getMountInfo(volume).mountpoint || mountInfo.mountpoint || '');
    const tries = [
      mp ? `umount ${shq(mp)} 2>&1` : null,
      `umount ${vq} 2>&1`,
      mp ? `umount -l ${shq(mp)} 2>&1` : null,
      `umount -l ${vq} 2>&1`,
      `fuser -vkm ${vq} 2>&1 || true`,
      mp ? `fuser -vkm ${shq(mp)} 2>&1 || true` : null,
      `umount -f ${vq} 2>&1 || true`,
      // stop udisks automount briefly
      `udisksctl unmount -b ${vq} 2>&1 || true`,
    ].filter(Boolean);
    for (const c of tries) {
      const r = await runCommandAsync(c, { timeout: 25000 });
      if (r.output && r.output.trim()) append(r.output.trim());
      if (!isMounted()) break;
    }
    await runCommandAsync('sync', { timeout: 10000 });
  }
  // drop read-only block flag if set
  await runCommandAsync(`blockdev --setrw ${vq} 2>&1 || true`, { timeout: 10000 });
  if (diskBase && diskBase !== volume) {
    await runCommandAsync(`blockdev --setrw ${shq(diskBase)} 2>&1 || true`, { timeout: 10000 });
  }
  mountInfo = getMountInfo(volume);
  append(isMounted()
    ? 'WARNING: still mounted — write stages may fail. Close file managers and retry.'
    : 'Volume offline — OK.');
  append('');

  // ---- Stage 1: diagnose ----
  const r1 = await stage('Stage 1: Diagnose (ntfsfix -n)', `${ntfsfix} -n ${vq}`, 180000);
  const dirtyHint = /dirty|unclean|hiber|chkdsk|windows/i.test(r1.output || '');

  // ---- Stage 2-5: multi-pass ntfsfix (chkdsk /f equivalent loop) ----
  const fixCodes = [];
  if (!isMounted()) {
    for (let pass = 1; pass <= 3; pass++) {
      const r = await stage(
        `Stage 2.${pass}: ntfsfix full fix pass (journal + fundamental)`,
        `${ntfsfix} ${vq}`,
        300000
      );
      fixCodes.push(r.code);
      const d = await stage(
        `Stage 3.${pass}: Clear dirty flag`,
        `${ntfsfix} -d ${vq}`,
        90000
      );
      fixCodes.push(d.code);
      const chk = await runCommandAsync(`${ntfsfix} -n ${vq}`, { timeout: 90000 });
      append(chk.output || '');
      if (!/dirty|unclean/i.test(chk.output || '') && (r.code === 0 || d.code === 0)) {
        append(`Clean after pass ${pass}.`);
        append('');
        break;
      }
      append(`Still inconsistent after pass ${pass} — continuing...`);
      append('');
    }
    const r4 = await stage('Stage 4: Clear bad-sector list (ntfsfix -b)', `${ntfsfix} -b ${vq}`, 180000);
    fixCodes.push(r4.code);
    const r5 = await stage('Stage 5: Extra ntfsfix pass after -b', `${ntfsfix} ${vq} ; ${ntfsfix} -d ${vq}`, 300000);
    fixCodes.push(r5.code);
  } else {
    append('--- Stages 2–5 SKIPPED (volume still mounted) ---');
    append('');
  }

  // ---- Stage 6: hibernation / Fast Startup removal (critical for USB from Windows) ----
  append('--- Stage 6: Remove Windows hibernation / Fast Startup lock ---');
  let hiberOk = false;
  if (!isMounted() && ntfs3gBin && isRoot()) {
    const mp = fs.mkdtempSync(path.join(os.tmpdir(), 'ntfsrepair-hiber-'));
    const mq = shq(mp);
    // Order: remove_hiberfile, then force, then windows_names
    const mountAttempts = [
      `${shq(ntfs3gBin)} -o remove_hiberfile,rw,force ${vq} ${mq} 2>&1; echo EC:$?`,
      `${shq(ntfs3gBin)} -o remove_hiberfile,rw ${vq} ${mq} 2>&1; echo EC:$?`,
      `${shq(ntfs3gBin)} -o force,rw ${vq} ${mq} 2>&1; echo EC:$?`,
      `mount -t ntfs3 -o rw,force ${vq} ${mq} 2>&1; echo EC:$?`,
    ];
    for (const mcmd of mountAttempts) {
      const mr = await stage('Stage 6 mount attempt', mcmd, 60000);
      if (/EC:0/.test(mr.output || '') || isMounted()) {
        hiberOk = true;
        // delete hibernation + pagefile leftovers that keep volume dirty
        const clean = await runCommandAsync(
          `ls -la ${mq}/hiberfil.sys ${mq}/Hiberfil.sys ${mq}/pagefile.sys ${mq}/swapfile.sys 2>&1 || true; ` +
          `rm -f ${mq}/hiberfil.sys ${mq}/Hiberfil.sys 2>&1 || true; ` +
          `sync; umount ${mq} 2>&1 || umount -l ${mq} 2>&1 || true`,
          { timeout: 90000 }
        );
        append(clean.output || '');
        append('Hibernation cleanup cycle done.');
        break;
      }
    }
    if (isMounted()) {
      await runCommandAsync(`umount ${vq} 2>&1 || umount -l ${vq} 2>&1 || true`, { timeout: 20000 });
    }
    try { fs.rmdirSync(mp); } catch (_) {}
    // After hiber clear, run ntfsfix -d again
    if (!isMounted()) {
      await stage('Stage 6b: ntfsfix -d after hiber cleanup', `${ntfsfix} -d ${vq}`, 90000);
      await stage('Stage 6c: ntfsfix full after hiber cleanup', `${ntfsfix} ${vq}`, 180000);
    }
  } else {
    append('Hibernation mount cycle skipped (need root, ntfs-3g, unmounted volume).');
  }
  append('');

  // ---- Stage 7: structure probe ----
  const r7 = await stage('Stage 7: Structure / MFT probe (ntfsinfo)', ntfsinfoCmd(volume, 120), 90000);

  // ---- Stage 8: surface scan (optional length - still run) ----
  append('--- Stage 8: Surface scan (read-only badblocks) ---');
  const r8 = await runCommandWithProgress(`Stage 8: Surface scan ${volume}`, `${badblocks} -sv ${vq}`, 600000);
  append(r8.output || '(no output)');
  append(`Exit code: ${r8.code}`);
  const foundBad = /bad blocks?/i.test(r8.output || '') && !/Pass completed, 0 bad blocks found/i.test(r8.output || '');
  if (foundBad) append('Bad blocks found — hardware may be failing; backup ASAP.');
  append('');

  // ---- Stage 9: final repair passes ----
  if (!isMounted()) {
    await stage('Stage 9a: Final ntfsfix', `${ntfsfix} ${vq}`, 300000);
    await stage('Stage 9b: Final dirty clear', `${ntfsfix} -d ${vq}`, 90000);
    await stage('Stage 9c: Final -b', `${ntfsfix} -b ${vq}`, 120000);
  } else {
    append('--- Stage 9 SKIPPED (mounted) ---');
    append('');
  }

  // ---- Stage 10: mount verification RO + RW + write ----
  append('--- Stage 10: Mount verification (RO / RW / write-test) ---');
  let mountOk = false, mountRwOk = false, writeOk = false;
  if (isRoot()) {
    // RO
    const mp = fs.mkdtempSync(path.join(os.tmpdir(), 'ntfsrepair-ro-'));
    const mq = shq(mp);
    const ro = await runCommandAsync(
      `(mount -t ntfs3 -o ro ${vq} ${mq} 2>&1 || ${ntfs3gBin ? shq(ntfs3gBin) + ' -o ro ' + vq + ' ' + mq + ' 2>&1' : 'false'}; echo EC:$?); findmnt -n ${mq} 2>&1; umount ${mq} 2>&1 || umount -l ${mq} 2>&1 || true`,
      { timeout: 45000 }
    );
    append('RO:');
    append(ro.output || '');
    mountOk = /EC:0/.test(ro.output || '');
    try { fs.rmdirSync(mp); } catch (_) {}

    // RW with remove_hiberfile
    const mp2 = fs.mkdtempSync(path.join(os.tmpdir(), 'ntfsrepair-rw-'));
    const mq2 = shq(mp2);
    const rwCmd = ntfs3gBin
      ? `(${shq(ntfs3gBin)} -o rw,remove_hiberfile,force ${vq} ${mq2} 2>&1 || mount -t ntfs3 -o rw ${vq} ${mq2} 2>&1; echo EC:$?)`
      : `(mount -t ntfs3 -o rw ${vq} ${mq2} 2>&1; echo EC:$?)`;
    const rw = await runCommandAsync(
      `${rwCmd}; findmnt -n ${mq2} 2>&1; touch ${mq2}/.ntfsrepair_wtest 2>&1; ecw=$?; rm -f ${mq2}/.ntfsrepair_wtest 2>&1; echo WRITE_EC:$ecw; umount ${mq2} 2>&1 || umount -l ${mq2} 2>&1 || true`,
      { timeout: 90000 }
    );
    append('RW + write-test:');
    append(rw.output || '');
    mountRwOk = /EC:0/.test(rw.output || '');
    writeOk = /WRITE_EC:0/.test(rw.output || '');
    try { fs.rmdirSync(mp2); } catch (_) {}
  } else {
    append('Skipped (not root).');
  }
  append('');

  // ---- Stage 11: if still not RW, last-resort recovery loop ----
  if (isRoot() && !writeOk && !isMounted()) {
    append('--- Stage 11: Last-resort recovery loop ---');
    await stage('LR1: ntfsfix', `${ntfsfix} ${vq}`, 300000);
    await stage('LR2: ntfsfix -d -b', `${ntfsfix} -d ${vq} ; ${ntfsfix} -b ${vq}`, 180000);
    if (ntfs3gBin) {
      const mp3 = fs.mkdtempSync(path.join(os.tmpdir(), 'ntfsrepair-lr-'));
      const mq3 = shq(mp3);
      const lr = await runCommandAsync(
        `${shq(ntfs3gBin)} -o rw,remove_hiberfile,force,windows_names ${vq} ${mq3} 2>&1; echo EC:$?; ` +
        `touch ${mq3}/.ntfsrepair_wtest 2>&1; echo WRITE_EC:$?; rm -f ${mq3}/.ntfsrepair_wtest; ` +
        `umount ${mq3} 2>&1 || umount -l ${mq3} 2>&1 || true`,
        { timeout: 90000 }
      );
      append(lr.output || '');
      if (/WRITE_EC:0/.test(lr.output || '')) {
        writeOk = true;
        mountRwOk = true;
        append('Last-resort RW write-test SUCCEEDED.');
      }
      try { fs.rmdirSync(mp3); } catch (_) {}
    }
    await stage('LR3: post ntfsfix -d', `${ntfsfix} -d ${vq}`, 90000);
    append('');
  }

  // ---- Stage 12: post-check ----
  const r12 = await stage('Stage 12: Post-check (ntfsfix -n)', `${ntfsfix} -n ${vq}`, 120000);
  const stillDirty = /dirty|unclean|hiber/i.test(r12.output || '');

  append('══════════════════════════════════════════════════════════════════');
  append('chkdsk NTFS fix - beta  SUMMARY  (v13.0.9 / Svn DtkQdev)');
  append('──────────────────────────────────────────────────────────────────');
  append(`  Diagnose:     code ${r1.code}${dirtyHint ? ' [dirty/hiber hints]' : ''}`);
  append(`  Fix passes:   ${fixCodes.join(', ') || 'n/a'}`);
  append(`  Hiber clear:  ${hiberOk ? 'attempted/ok' : 'skipped or failed'}`);
  append(`  Surface:      code ${r8.code}${foundBad ? ' [BAD BLOCKS]' : ''}`);
  append(`  Mount RO/RW:  ${mountOk ? 'RO-OK' : 'RO-FAIL'} / ${mountRwOk ? 'RW-OK' : 'RW-FAIL'} write=${writeOk ? 'OK' : 'FAIL'}`);
  append(`  Post-check:   code ${r12.code}${stillDirty ? ' [still dirty]' : ''}`);
  append('');
  if (writeOk && !stillDirty) {
    append('RESULT: SUCCESS — volume accepts read/write on Linux without Windows.');
    append(`  Mount example:  sudo mkdir -p /mnt/usb && sudo ${ntfs3gBin || 'ntfs-3g'} ${volume} /mnt/usb`);
  } else if (mountOk && !writeOk) {
    append('RESULT: Readable but not fully writable.');
    append('  Typical cause: Windows Fast Startup/hibernation still locking metadata.');
    append('  Try: fully Shut down Windows (not Restart), or from Windows: powercfg /h off');
    append('  Then re-run option 15 as root. If still failing, Windows: chkdsk X: /f /r');
  } else if (stillDirty) {
    append('RESULT: Still dirty after full Linux kit.');
    append('  Linux ntfsfix cannot rebuild complex MFT/index damage.');
    append('  Next: Windows chkdsk X: /f /r  OR backup with ddrescue and reformat.');
  } else if (foundBad) {
    append('RESULT: Bad sectors reported — backup data; disk may be failing.');
  } else {
    append('RESULT: Repair finished — review stages. Re-plug USB and retry mount.');
  }
  append('══════════════════════════════════════════════════════════════════');

  const status = (writeOk && !stillDirty && !foundBad) ? 'success' : 'warning';
  return {
    status,
    summary: writeOk && !stillDirty
      ? 'chkdsk-beta: RW OK — volume fixed for Linux use'
      : stillDirty
        ? 'chkdsk-beta: still dirty after full kit'
        : writeOk
          ? 'chkdsk-beta: RW OK (minor warnings)'
          : `chkdsk-beta: RO=${mountOk} RW=${mountRwOk} write=${writeOk}`,
    output: out,
  };
}


// ============================================
// Option 17: FORCE MOUNT (data loss assumed)
// Aggressive path only — no "safe" mount. Clears dirty/hiber flags, then
// mounts with force/rw/remove_hiberfile. May overwrite metadata state.
// ============================================
async function runForceMount(volume, mountInfo, preface = '') {
  let out = preface || '';
  const append = (s = '') => { out += String(s).replace(/\r\n/g, '\n') + (String(s).endsWith('\n') ? '' : '\n'); };
  const ntfsfixBin = resolveToolPath('ntfsfix');
  const ntfs3gBin = resolveToolPath('ntfs-3g');
  const badblocksBin = resolveToolPath('badblocks');
  const ntfsfix = shq(ntfsfixBin || 'ntfsfix');
  const vq = shq(volume);

  const WARN =
    'Linux already has NTFS drivers that can read and write NTFS, and the kernel\'s ntfs3 driver supports journal replay. ' +
    'But a driver\'s job is normal filesystem access—not necessarily discovering and safely repairing every possible contradiction in a damaged filesystem. ' +
    'badblocks is different: it checks a drive for unreadable blocks; it doesn\'t repair NTFS metadata. ' +
    'System avoid its write mode on a disk containing data, because it overwrites data.';

  clearScreen();
  await drawHeader({ showVolumes: true, showMountingErrors: false });
  console.log('');
  console.log(boxen(
    colors.danger('FORCE MOUNT — DATA LOSS ASSUMED') + '\n\n' +
    colors.warning(WARN) + '\n\n' +
    colors.optionDesc('This option uses ONLY the aggressive path (no safe/read-only mount):') + '\n' +
    colors.optionDesc('force unmount → multi-pass ntfsfix → optional badblocks note → force RW mount.') + '\n' +
    colors.danger('Continue only if you accept possible data loss / overwritten metadata.'),
    { padding: 1, margin: 1, borderStyle: 'round', borderColor: 'red' }
  ));

  const { go } = await safePrompt([{
    type: 'confirm',
    name: 'go',
    message: colors.danger('I understand data may be lost / overwritten. Continue force mount?'),
    default: false,
  }], 'force mount confirm');
  if (!go) {
    return { status: 'warning', summary: 'force mount cancelled by user', output: out + 'Cancelled by user.\n' };
  }
  const { go2 } = await safePrompt([{
    type: 'confirm',
    name: 'go2',
    message: colors.danger('FINAL CONFIRM: force mount ' + volume + ' now?'),
    default: false,
  }], 'force mount final confirm');
  if (!go2) {
    return { status: 'warning', summary: 'force mount cancelled by user', output: out + 'Cancelled at final confirm.\n' };
  }

  append('FORCE MOUNT (data loss assumed) — ' + volume);
  append(WARN);
  append('');

  // A: force offline
  append('--- A: Force unmount ---');
  await runCommandAsync('sync', { timeout: 10000 });
  if (mountInfo.mounted || getMountInfo(volume).mounted) {
    const mp = getMountInfo(volume).mountpoint || mountInfo.mountpoint || '';
    for (const c of [
      mp ? `umount ${shq(mp)} 2>&1` : null,
      `umount ${vq} 2>&1`,
      `umount -l ${vq} 2>&1`,
      `fuser -vkm ${vq} 2>&1 || true`,
      `udisksctl unmount -b ${vq} 2>&1 || true`,
      `umount -f ${vq} 2>&1 || true`,
    ].filter(Boolean)) {
      const r = await runCommandAsync(c, { timeout: 20000 });
      if (r.output && r.output.trim()) append(r.output.trim());
      if (!getMountInfo(volume).mounted) break;
    }
  }
  await runCommandAsync(`blockdev --setrw ${vq} 2>&1 || true`, { timeout: 8000 });
  append(getMountInfo(volume).mounted ? 'Still mounted (continuing).' : 'Offline OK.');
  append('');

  // B: multi-pass metadata repair (ntfsfix — not badblocks write mode)
  append('--- B: NTFS metadata repair (ntfsfix multi-pass; NOT badblocks -w) ---');
  append('badblocks write mode is intentionally NOT used here (it overwrites user data).');
  if (ntfsfixBin) {
    for (const [label, cmd] of [
      ['diagnose', `${ntfsfix} -n ${vq}`],
      ['full fix', `${ntfsfix} ${vq}`],
      ['clear dirty', `${ntfsfix} -d ${vq}`],
      ['clear bad-sector list', `${ntfsfix} -b ${vq}`],
      ['full fix again', `${ntfsfix} ${vq}`],
      ['clear dirty again', `${ntfsfix} -d ${vq}`],
    ]) {
      const r = await runCommandWithProgress('Force: ' + label, cmd, 180000);
      append(`$ ${cmd}`);
      append(r.output || '(no output)');
      append(`exit=${r.code}`);
      append('');
    }
  } else {
    append('ntfsfix missing — install via ./install.sh');
  }

  // C: read-only badblocks surface check only (never -w)
  if (badblocksBin) {
    append('--- C: badblocks READ-ONLY surface check (no -w / no overwrite) ---');
    const r = await runCommandWithProgress('Force: badblocks -sv (RO)', `${shq(badblocksBin)} -sv ${vq}`, 300000);
    append(r.output || '');
    append(`exit=${r.code}`);
    if (/bad blocks?/i.test(r.output || '') && !/0 bad blocks found/i.test(r.output || '')) {
      append('Unreadable blocks reported. Force mount may still work; data on bad sectors can be lost.');
    }
    append('');
  }

  // D: FORCE mount only
  append('--- D: FORCE mount (rw, force, remove_hiberfile) — no safe RO path ---');
  const mp = fs.mkdtempSync(path.join(os.tmpdir(), 'ntfsrepair-force-'));
  const mq = shq(mp);
  let mounted = false;
  let writeOk = false;
  const attempts = [];
  if (ntfs3gBin) {
    attempts.push(`${shq(ntfs3gBin)} -o force,rw,remove_hiberfile,windows_names,allow_other ${vq} ${mq} 2>&1; echo EC:$?`);
    attempts.push(`${shq(ntfs3gBin)} -o force,rw,remove_hiberfile ${vq} ${mq} 2>&1; echo EC:$?`);
    attempts.push(`${shq(ntfs3gBin)} -o force,rw ${vq} ${mq} 2>&1; echo EC:$?`);
  }
  attempts.push(`mount -t ntfs3 -o rw,force ${vq} ${mq} 2>&1; echo EC:$?`);
  attempts.push(`mount -t ntfs-3g -o force,rw,remove_hiberfile ${vq} ${mq} 2>&1; echo EC:$?`);

  for (const mcmd of attempts) {
    if (getMountInfo(volume).mounted) {
      await runCommandAsync(`umount ${mq} 2>&1 || umount -l ${mq} 2>&1 || umount ${vq} 2>&1 || true`, { timeout: 15000 });
    }
    const r = await runCommandWithProgress('Force mount attempt', mcmd, 60000);
    append(`$ ${mcmd}`);
    append(r.output || '');
    append('');
    if (/EC:0/.test(r.output || '') || getMountInfo(volume).mounted) {
      mounted = true;
      // remove hiber files if present
      const hib = await runCommandAsync(
        `rm -f ${mq}/hiberfil.sys ${mq}/Hiberfil.sys 2>&1 || true; ` +
        `touch ${mq}/.ntfsrepair_force_wtest 2>&1; echo WRITE_EC:$?; rm -f ${mq}/.ntfsrepair_force_wtest 2>&1; findmnt -n ${mq} 2>&1 || true`,
        { timeout: 30000 }
      );
      append(hib.output || '');
      writeOk = /WRITE_EC:0/.test(hib.output || '');
      append(`Mount point: ${mp}`);
      append('Unmount later: sudo umount ' + mp);
      break;
    }
  }
  if (!mounted) {
    append('FORCE MOUNT FAILED.');
    try { fs.rmdirSync(mp); } catch (_) {}
  } else if (ntfsfixBin && !getMountInfo(volume).mounted) {
    // remount cycle done — optional post dirty clear if they unmounted
  }

  // E: if still not mounted, last ntfsfix + retry one force mount
  if (!mounted && ntfsfixBin && !getMountInfo(volume).mounted) {
    append('--- E: Last-resort ntfsfix + one more force mount ---');
    await runCommandWithProgress('LR ntfsfix', `${ntfsfix} ${vq} ; ${ntfsfix} -d ${vq}`, 300000);
    if (ntfs3gBin) {
      const r = await runCommandWithProgress(
        'LR force mount',
        `${shq(ntfs3gBin)} -o force,rw,remove_hiberfile ${vq} ${mq} 2>&1; echo EC:$?`,
        60000
      );
      append(r.output || '');
      if (/EC:0/.test(r.output || '')) {
        mounted = true;
        const wt = await runCommandAsync(`touch ${mq}/.w 2>&1; echo WRITE_EC:$?; rm -f ${mq}/.w`, { timeout: 15000 });
        append(wt.output || '');
        writeOk = /WRITE_EC:0/.test(wt.output || '');
        append(`Mount point: ${mp}`);
      }
    }
  }

  append('');
  append('══════════════════════════════════════');
  append(mounted
    ? (writeOk ? 'RESULT: Force-mounted RW with write access.' : 'RESULT: Force-mounted (write limited).')
    : 'RESULT: Could not force-mount.');
  append('Data integrity is not guaranteed after this operation.');
  append('══════════════════════════════════════');

  return {
    status: mounted ? (writeOk ? 'success' : 'warning') : 'danger',
    summary: mounted
      ? (writeOk ? `force-mounted RW at ${mp}` : `force-mounted (limited write) at ${mp}`)
      : 'force mount failed',
    output: out,
  };
}

async function runGuidedDdFix(volume, mountInfo, preface = '') {
  let out = preface || '';
  const append = (s='') => { out += String(s).replace(/\r\n/g, '\n') + (String(s).endsWith('\n') ? '' : '\n'); };
  append('GUIDED DD BAD BLOCK FIX (TARGETED ONLY)');
  append('This tool can overwrite specific blocks/sectors with zeros. It can DESTROY DATA if used incorrectly.');
  append('It will NOT wipe the whole device automatically.');
  append('');
  if (mountInfo.mounted) {
    append('ABORTED: Volume is mounted. Unmount it before any dd write operation.');
    return { status: 'danger', summary: 'aborted (volume mounted)', output: out };
  }

  clearScreen();
  await drawHeader({ showVolumes: true, showMountingErrors: false });
  console.log(boxen(colors.danger('DANGEROUS OPERATION: targeted dd write') + '\n\n' +
    colors.optionDesc('You must specify block size and target blocks/sectors. Only those ranges will be written.\n') +
    colors.optionDesc('Recommended: run option 6 (badblocks read-only scan) first and use reported block numbers with the same block size.\n') +
    colors.warning('Back up important data before proceeding.'), { padding: 1, margin: 1, borderStyle: 'round', borderColor: 'red' }));

  const { proceed } = await safePrompt([{ type: 'confirm', name: 'proceed', message: colors.danger(`Proceed with guided dd on ${volume}?`), default: false }], 'guided dd confirmation');
  if (!proceed) {
    append('User cancelled guided dd operation.');
    return { status: 'warning', summary: 'cancelled by user', output: out };
  }

  const ans = await safePrompt([
    { type: 'input', name: 'bs', message: colors.info('Block size in bytes (e.g. 4096):'), default: '4096', validate: v => (/^\d+$/.test(v) && Number(v) > 0) || 'Enter a positive integer' },
    { type: 'input', name: 'targets', message: colors.info('Bad block numbers (comma/space separated, e.g. "128 133 200"):'), validate: v => (String(v).trim().length > 0) || 'Provide at least one block number' },
    { type: 'input', name: 'count', message: colors.info('Blocks to write per target (usually 1):'), default: '1', validate: v => (/^\d+$/.test(v) && Number(v) > 0) || 'Enter a positive integer' },
  ], 'guided dd parameters');

  const bs = Number(ans.bs);
  const count = Number(ans.count);
  const targets = String(ans.targets).split(/[\s,]+/).map(s => s.trim()).filter(Boolean);
  const invalid = targets.filter(t => !/^\d+$/.test(t));
  if (invalid.length) {
    append('Invalid block numbers: ' + invalid.join(', '));
    return { status: 'warning', summary: 'invalid block input', output: out };
  }

  append(`Parameters: bs=${bs} count=${count} targets=${targets.join(',')}`);
  append('');
  for (const t of targets) {
    const cmd = `${shq(resolveToolPath('dd'))} if=/dev/zero of=${shq(volume)} bs=${bs} seek=${t} count=${count} conv=notrunc,fsync status=none`;
    append(`$ ${cmd}`);
    const { confirmOne } = await safePrompt([{ type: 'confirm', name: 'confirmOne', message: colors.danger(`Write ${count} block(s) at offset ${t} (bs=${bs}) on ${volume}?`), default: false }], 'guided dd block confirmation');
    if (!confirmOne) {
      append(`Skipped target ${t} (user declined).`);
      append('');
      continue;
    }
    const r = await runCommandWithProgress(`dd overwrite block ${t} on ${volume}`, cmd, 60000);
    append(r.output && r.output.trim() ? r.output.trim() : '(no output)');
    append(`exit_code=${r.code}`);
    append('');
  }
  append('Completed guided dd pass. Re-run integrity checks (option 3) and consider filesystem repair/chkdsk as needed.');
  return { status: 'warning', summary: 'guided targeted dd completed (review output)', output: out };
}

// ============================================
// SCREENS: INFO / HELP / SYSTEM DEPS / ADVANCED
// ============================================

async function showHelp() {
  clearScreen();
  await drawHeader({ showVolumes: true, showMountingErrors: false });
  const help = [
    colors.title('NTFS-REPAIR Help & Usage'),
    '',
    colors.optionLabel('Workflow:'),
    `  ${colors.optionNumber('1.')} Select one or more NTFS volumes (option 1).`,
    `  ${colors.optionNumber('2.')} Run diagnostics (3, 4) before repairs when possible.`,
    `  ${colors.optionNumber('3.')} Unmount volumes before write operations when possible.`,
    `  ${colors.optionNumber('4.')} For Windows hibernation/Fast Startup issues, fully shut down Windows.`,
    '',
    colors.optionLabel('Marker behavior:'),
    `  ${colors.optionDesc('Initial: random marker, white, inside white brackets [x].')}`,
    `  ${colors.optionDesc('Completed: marker changes to a new random special character and random color (brackets stay white).')}`,
    `  ${colors.optionDesc('Re-run: marker/color changes again for that option; other completed options keep their current markers.')}`,
    `  ${colors.optionDesc('Restart app: all markers reset to initial white state.')}`,
    '',
    colors.optionLabel('Keyboard:'),
    `  ${colors.optionDesc('UP / DOWN: move   |   ENTER: select / confirm   |   Ctrl+C: quit')}`,
    `  ${colors.optionDesc('Volume list (option 1): SPACE ticks/unticks a volume, "a" toggles all, ENTER confirms.')}`,
    '',
    colors.optionLabel('Option notes:'),
    `  ${colors.optionNumber('[4]')} Mounting errors check stores a report shown only on the main menu (other menus stay clean).`,
    `  ${colors.optionNumber('[6]')} Bad blocks scan is read-only by default; use [16] only for targeted writes.`,
    `  ${colors.optionNumber('[15]')} chkdsk NTFS fix - beta: multi-phase Linux kit (ntfsfix stages mapped to chkdsk /f [/r]).`,
    `  ${colors.danger('[16]')} DD fix is destructive; targeted blocks only, requires confirmation.`,
    `  ${colors.danger('[17]')} Force mount assumes data loss; aggressive force/rw mount only (no safe path).`,
    '',
    colors.optionLabel('Commands:'),
    `  ${colors.info('sudo ntfs-repair')}   ${colors.dim('(alias: sudo ksvn, sudo ntfsre-pair)')}`,
    '',
    colors.warning('Always back up important data before repair operations. Some NTFS issues require Windows chkdsk.'),
  ].join('\n');
  console.log(boxen(help, { padding: 1, margin: 1, borderStyle: 'round', borderColor: 'cyan' }));
  await safePrompt([{ type: 'input', name: 'c', message: colors.subtitle('Press ENTER to return...') }], 'help screen');
}

function keyImageInfo() {
  if (!chafaLib) return `unavailable - static-chafa could not be loaded (${chafaLoadError && chafaLoadError.message ? String(chafaLoadError.message).split('\n')[0] : 'unknown error'}); the app works without it`;
  if (!getChafa()) return `unavailable - static-chafa failed to initialise (${chafaLoadError && chafaLoadError.message ? String(chafaLoadError.message).split('\n')[0] : 'unknown error'})`;
  const size = computeKeyImageSize();
  if (!size) return `hidden - terminal too small (needs at least ${KEY_IMG_ROWS_RESERVED + KEY_IMG_MIN_ROWS} rows and ${Math.round(KEY_IMG_COLS * KEY_IMG_MIN_ROWS / KEY_IMG_ROWS) + 2} columns)`;
  return `redkeys.png via static-chafa, ${size.cols}x${size.rows} text cells (~2:1), no rotation, no tint, scaled to this terminal`;
}

async function showInformations() {
  clearScreen();
  await drawHeader({ showVolumes: true, showMountingErrors: false });

  const tools = [
    'ntfsfix', 'ntfs-3g', 'ntfsinfo', 'mkntfs', 'lowntfs-3g', 'ntfs-3g.probe',
    'badblocks', 'blkid', 'lsblk', 'findmnt', 'mount', 'umount',
    'dmesg', 'journalctl', 'dd', 'blockdev', 'fuser', 'udisksctl', 'sync',
  ];
  let toolLines = '';
  for (const t of tools) {
    const p = findExecutable(t);
    const exists = !!p;
    toolLines += `  ${exists ? colors.success('✓') : colors.warning('✗')} ${colors.optionNumber(t.padEnd(12))} ${colors.optionDesc(exists ? p : 'not found')}\n`;
  }

  let volInfo = '';
  if (sessionState.selectedVolumes.length) {
    for (const v of sessionState.selectedVolumes) {
      const mi = getMountInfo(v);
      volInfo += `  ${colors.optionNumber(v)} ${colors.optionDesc(mi.mounted ? `mounted at ${mi.mountpoint} (${mi.options})` : 'not mounted')}\n`;
      const info = runCommandCapture(commandExists('ntfsinfo') ? ntfsinfoCmd(v, 20) : `blkid ${shq(v)} 2>&1 | head -20`, { timeout: 10000 });
      if (info.output && info.output.trim()) {
        volInfo += colors.dim(info.output.trim().split('\n').map(l => '    ' + l).join('\n')) + '\n';
      }
    }
  } else {
    volInfo = `  ${colors.dim('No volumes selected.')}\n`;
  }

  const body = [
    colors.optionLabel('Application'),
    `  ${colors.optionNumber('Name:')}      ${colors.info('NTFS-REPAIR')}`,
    `  ${colors.optionNumber('Version:')}   ${colors.info(APP_VERSION)}`,
    `  ${colors.optionNumber('Author:')}    ${colors.info(APP_AUTHOR)}`,
    `  ${colors.optionNumber('App dir:')}   ${colors.info(APP_DIR)}`,
    '',
    colors.optionLabel('Runtime'),
    `  ${colors.optionNumber('Node:')}      ${colors.info(process.version)}`,
    `  ${colors.optionNumber('Platform:')}  ${colors.info(process.platform + ' (' + process.arch + ')')}`,
    `  ${colors.optionNumber('Root:')}      ${isRoot() ? colors.success('YES') : colors.warning('NO')}`,
    '',
    colors.optionLabel('System dependencies / tools'),
    toolLines.trimEnd(),
    '',
    colors.optionLabel('Node / runtime packages (bundled with install)'),
    `  ${colors.optionNumber('inquirer')} ${colors.optionDesc('interactive menus')}`,
    `  ${colors.optionNumber('chalk')} ${colors.optionDesc('terminal colors')}`,
    `  ${colors.optionNumber('figlet')} ${colors.optionDesc('title banner')}`,
    `  ${colors.optionNumber('gradient-string')} ${colors.optionDesc('title gradient')}`,
    `  ${colors.optionNumber('boxen')} ${colors.optionDesc('result boxes')}`,
    `  ${colors.optionNumber('static-chafa')} ${colors.optionDesc('key image rendering')}`,
    `  ${colors.optionNumber('ora / cli-spinners')} ${colors.optionDesc('spinners (optional UI)')}`,
    '',
    colors.optionLabel('Install-time system packages (install.sh)'),
    `  ${colors.optionDesc('ntfs-3g / ntfsprogs (ntfsfix, ntfsinfo, mkntfs)')}`,
    `  ${colors.optionDesc('e2fsprogs (badblocks)')}`,
    `  ${colors.optionDesc('util-linux (lsblk, blkid, findmnt, mount, umount, blockdev)')}`,
    `  ${colors.optionDesc('coreutils / psmisc (dd, sync, fuser) — usually preinstalled')}`,
    '',
    colors.optionLabel('Local deps paths'),
    `  ${colors.optionNumber('deps dir:')}  ${colors.info(DEPS_DIR)}`,
    `  ${colors.optionNumber('bin dir:')}   ${colors.info(DEPS_BIN_DIR)}`,
    `  ${colors.optionNumber('env.sh:')}    ${colors.info(DEPS_ENV_SCRIPT)}`,
    '',
    colors.optionLabel('Selected volume(s)'),
    volInfo.trimEnd(),
    '',
    colors.optionLabel('Key image'),
    `  ${colors.optionDesc(keyImageInfo())}`,
  ].join('\n');

  console.log(boxen(colors.title('NTFS-REPAIR - Informations') + '\n\n' + body, { padding: 1, margin: 1, borderStyle: 'round', borderColor: 'cyan' }));
  await safePrompt([{ type: 'input', name: 'c', message: colors.subtitle('Press ENTER to return...') }], 'informations screen');
}

async function executeSystemDepsMenu() {
  while (true) {
    clearScreen();
    await drawHeader({ showVolumes: true, showMountingErrors: false });
    const localTools = ['ntfsfix', 'ntfs-3g', 'ntfsinfo', 'mkntfs', 'badblocks'];
    let status = '';
    for (const t of localTools) {
      const p = path.join(DEPS_BIN_DIR, t);
      status += `  ${fs.existsSync(p) ? colors.success('✓') : colors.warning('✗')} ${colors.optionNumber(t)} ${colors.dim(fs.existsSync(p) ? p : 'missing')}\n`;
    }
    console.log(boxen(colors.title('System Dependencies (local build/install)') + '\n\n' + colors.optionLabel('Local tool status:') + '\n' + status + '\n' + colors.optionLabel('Paths:') + '\n' + `  ${colors.optionDesc('App:')} ${colors.info(APP_DIR)}\n  ${colors.optionDesc('Deps:')} ${colors.info(DEPS_DIR)}\n  ${colors.optionDesc('Env:')} ${colors.info(DEPS_ENV_SCRIPT)}`, { padding: 1, margin: 1, borderStyle: 'round', borderColor: 'cyan' }));

    const { action } = await safePrompt([{
      type: 'list',
      name: 'action',
      message: colors.info('System dependencies action:'),
      choices: [
        { name: colors.success('Install/Reinstall all from source (local deps)'), value: 'install' },
        { name: colors.info('Verify installation status'), value: 'verify' },
        { name: colors.warning('Troubleshooting tips'), value: 'troubleshoot' },
        { name: colors.optionDesc('Show package manager commands'), value: 'pkg' },
        { name: colors.optionDesc('Show env.sh'), value: 'env' },
        { name: colors.optionDesc('Clean build directory'), value: 'clean' },
        new inquirer.Separator(),
        { name: colors.warning('← Back'), value: 'back' },
      ],
      pageSize: 12,
    }], 'system deps menu');

    if (action === 'back') return;
    if (action === 'install') await runSystemDepsInstall();
    else if (action === 'verify') await verifyInstallation();
    else if (action === 'troubleshoot') await troubleshootDeps();
    else if (action === 'pkg') await showPkgManagerCommands();
    else if (action === 'env') await showEnvScript();
    else if (action === 'clean') await cleanBuildDir();
  }
}

async function runSystemDepsInstall() {
  clearScreen();
  await drawHeader({ showVolumes: true, showMountingErrors: false });
  const scriptPath = path.join(APP_DIR, 'install-system-deps.sh');
  if (!fs.existsSync(scriptPath)) {
    await showResultScreen({ title: 'Installer script does not exist', status: 'warning', summaryLines: [`Installer script does not exist: ${scriptPath}`] });
    return;
  }
  const { proceed } = await safePrompt([{ type: 'confirm', name: 'proceed', message: colors.info('Run local source installer for ntfs-3g/ntfsprogs and e2fsprogs?'), default: true }], 'system deps install confirmation');
  if (!proceed) return;
  if (!isRoot()) {
    await showResultScreen({ title: 'Root required', status: 'warning', summaryLines: ['Run NTFS-REPAIR with sudo to install into deps/usr.'] });
    return;
  }
  console.log(colors.info('\nRunning installer script...\n'));
  const code = await new Promise((resolve) => {
    const child = spawn('bash', [scriptPath], { cwd: APP_DIR, stdio: 'inherit' });
    child.on('close', (c) => resolve(c ?? 1));
    child.on('error', () => resolve(1));
  });
  toolCache.clear(); // the installer may have created new tools under ./deps/usr/bin
  await showResultScreen({
    title: code === 0 ? 'System dependencies installation finished' : 'System dependencies installation failed',
    status: code === 0 ? 'success' : 'warning',
    summaryLines: [code === 0 ? `Local tools installed under ${DEPS_DIR}` : `Installer exited with code ${code}`],
    output: code === 0 ? `Use: source ${DEPS_ENV_SCRIPT}` : '',
  });
}

async function verifyInstallation() {
  const localTools = [
    { name: 'ntfsfix', cmd: `${shq(path.join(DEPS_BIN_DIR,'ntfsfix'))} --version 2>&1 | head -1` },
    { name: 'ntfs-3g', cmd: `${shq(path.join(DEPS_BIN_DIR,'ntfs-3g'))} --version 2>&1 | head -1` },
    { name: 'ntfsinfo', cmd: `${shq(path.join(DEPS_BIN_DIR,'ntfsinfo'))} --version 2>&1 | head -1` },
    { name: 'mkntfs', cmd: `${shq(path.join(DEPS_BIN_DIR,'mkntfs'))} --version 2>&1 | head -1` },
    { name: 'badblocks', cmd: `${shq(path.join(DEPS_BIN_DIR,'badblocks'))} -V 2>&1 | head -2` },
  ];
  let out = '';
  let ok = 0;
  for (const t of localTools) {
    const p = path.join(DEPS_BIN_DIR, t.name);
    if (fs.existsSync(p)) {
      ok++;
      const v = runCommandCapture(t.cmd, { timeout: 5000 }).output.trim();
      out += `✓ ${t.name}: ${p}\n  ${v || '(version unavailable)'}\n`;
    } else {
      out += `✗ ${t.name}: does not exist / missing (${p})\n`;
    }
  }
  out += `\nenv.sh: ${fs.existsSync(DEPS_ENV_SCRIPT) ? 'present' : 'does not exist / missing'} (${DEPS_ENV_SCRIPT})\n`;
  await showResultScreen({ title: 'Local dependency verification', status: ok === localTools.length ? 'success' : 'warning', summaryLines: [`${ok}/${localTools.length} local tools found in ${DEPS_BIN_DIR}`], output: out.trim() });
}

async function troubleshootDeps() {
  const out = [
    'Common issues:',
    '- Missing build tools: install gcc, make, pkg-config, autoconf, automake, libtool, fuse dev headers, uuid/blkid dev headers.',
    '- Permission errors: run installer with sudo so it can write to deps/usr.',
    '- Download failures: check network access and source URLs in install-system-deps.sh.',
    '- Runtime shared library issues: source deps/env.sh to set PATH/LD_LIBRARY_PATH/PKG_CONFIG_PATH.',
    '- ntfsfix flags vary by build/version; the app uses common flags and reports command output/exit codes.',
    '',
    `Diagnostics:`,
    `  ls -la "${DEPS_BIN_DIR}"`,
    `  source "${DEPS_ENV_SCRIPT}"`,
    `  ldd "${path.join(DEPS_BIN_DIR,'ntfsfix')}" 2>&1 | head`,
  ].join('\n');
  await showResultScreen({ title: 'Dependency troubleshooting', status: 'info', summaryLines: ['Tips for local source-built dependencies.'], output: out });
}

async function showPkgManagerCommands() {
  const out = [
    '# Debian/Ubuntu',
    'sudo apt update && sudo apt install -y ntfs-3g ntfs-3g-dev e2fsprogs build-essential pkg-config libfuse-dev uuid-dev libblkid-dev',
    '',
    '# Arch/CachyOS/Manjaro',
    'sudo pacman -Sy --needed ntfs-3g e2fsprogs base-devel pkgconf fuse2 util-linux-libs',
    '',
    '# Fedora/RHEL',
    'sudo dnf install -y ntfs-3g ntfsprogs e2fsprogs @development-tools pkgconf fuse-devel libuuid-devel libblkid-devel',
    '',
    '# openSUSE',
    'sudo zypper install -y ntfs-3g e2fsprogs gcc make pkgconf fuse-devel libuuid-devel libblkid-devel',
    '',
    'Note: Local source build (option 12: Install/Reinstall all from source) is preferred for this app; package manager installs are useful for quick troubleshooting.',
  ].join('\n');
  await showResultScreen({ title: 'Package manager commands', status: 'info', summaryLines: ['Reference commands (distro-dependent).'], output: out });
}

async function showEnvScript() {
  let out = '';
  if (fs.existsSync(DEPS_ENV_SCRIPT)) out = fs.readFileSync(DEPS_ENV_SCRIPT, 'utf8');
  else out = `env.sh does not exist at ${DEPS_ENV_SCRIPT}. Run the local dependency installer first.`;
  await showResultScreen({ title: 'Environment script (env.sh)', status: fs.existsSync(DEPS_ENV_SCRIPT) ? 'info' : 'warning', summaryLines: [DEPS_ENV_SCRIPT], output: out });
}

async function cleanBuildDir() {
  const buildDir = path.join(DEPS_DIR, 'build');
  const { proceed } = await safePrompt([{ type: 'confirm', name: 'proceed', message: colors.warning(`Delete build directory ${buildDir}?`), default: false }], 'clean build dir confirmation');
  if (!proceed) return;
  if (fs.existsSync(buildDir)) {
    fs.rmSync(buildDir, { recursive: true, force: true });
    await showResultScreen({ title: 'Build directory cleaned', status: 'success', summaryLines: [buildDir] });
  } else {
    await showResultScreen({ title: 'Build directory does not exist', status: 'warning', summaryLines: [`Build directory does not exist: ${buildDir}`] });
  }
}

async function showAdvancedOptions() {
  while (true) {
    clearScreen();
    await drawHeader({ showVolumes: true, showMountingErrors: false });
    console.log(boxen(colors.title('Advanced Options') + '\n\n' + colors.optionDesc('Additional diagnostics and guided utilities for selected volume(s).'), { padding: 1, margin: 1, borderStyle: 'round', borderColor: 'cyan' }));
    const { action } = await safePrompt([{
      type: 'list',
      name: 'action',
      message: colors.info('Select advanced action:'),
      choices: [
        { name: 'Show detailed NTFS volume info (ntfsinfo -m)', value: 'ntfsinfo' },
        { name: 'Show blkid/lsblk/findmnt details', value: 'blk' },
        { name: 'Attempt read-only mount test (temporary mountpoint)', value: 'mounttest' },
        { name: 'List recent NTFS/kernel log entries', value: 'logs' },
        new inquirer.Separator(),
        { name: colors.warning('← Back'), value: 'back' },
      ],
      pageSize: 10,
    }], 'advanced options menu');
    if (action === 'back') return;
    await runAdvancedAction(action);
  }
}

async function runAdvancedAction(action) {
  const volumes = sessionState.selectedVolumes;
  if (volumes.length === 0) {
    await showResultScreen({ title: 'No volumes selected', status: 'warning', summaryLines: ['Select volumes first (option 1).'] });
    return;
  }
  let out = '';
  for (const v of volumes) {
    const vq = shq(v);
    out += `\n===== ${v} =====\n`;
    let r = null;
    if (action === 'ntfsinfo') {
      r = await runCommandWithProgress(`Reading NTFS volume info (${v})`, ntfsinfoCmd(v, 1000), 20000);
    } else if (action === 'blk') {
      r = await runCommandWithProgress(`Reading blkid/lsblk/findmnt details (${v})`, `blkid -o full ${vq} 2>&1; echo; lsblk -O ${vq} 2>&1 | head -80; echo; findmnt -n -o TARGET,FSTYPE,OPTIONS,SOURCE ${vq} 2>&1 || echo "not mounted"`, 15000);
    } else if (action === 'mounttest') {
      if (!isRoot()) {
        out += 'Root required for mount test.\n';
        continue;
      }
      // mkdtemp: private, unpredictable directory (the old fixed /tmp/ntfsrepair-mounttest-<pid> name could be pre-created by another user)
      const mp = fs.mkdtempSync(path.join(os.tmpdir(), 'ntfsrepair-mounttest-'));
      const mq = shq(mp);
      const cmd = `(mount -t ntfs3 -o ro ${vq} ${mq} 2>&1 || mount -t ntfs-3g -o ro ${vq} ${mq} 2>&1); ec=$?; echo "---MOUNT_EXIT:$ec---"; findmnt -n ${mq} 2>&1 || true; umount ${mq} 2>&1 || true; rmdir ${mq} 2>&1 || true`;
      r = await runCommandWithProgress(`Read-only mount test (${v})`, cmd, 30000);
      try { fs.rmdirSync(mp); } catch (_) { /* already removed by the command */ }
    } else if (action === 'logs') {
      const re = new RegExp('ntfs|' + escapeRegExp(v.replace('/dev/', '')), 'i');
      r = await runWithProgress(`Reading kernel/journal logs (${v})`, async () => {
        const dm = await runCommandAsync('dmesg -T 2>&1', { timeout: 15000 });
        const jr = await runCommandAsync('journalctl -k --no-pager -n 200 2>&1', { timeout: 15000 });
        return { output: filterLogLines(dm.output, re, 'No dmesg entries', 60) + '\n\n' + filterLogLines(jr.output, re, 'No journal entries', 60) };
      });
    }
    if (r) out += (r.output || '') + '\n';
  }
  await showResultScreen({ title: 'Advanced action result', status: 'info', summaryLines: [`Action: ${action}`, `Volumes: ${volumes.join(', ')}`], output: out.trim() });
}

// ============================================
// MAIN EXECUTION / MENU
// ============================================

function markOptionCompleted(optionId) {
  const marker = getRandomMarker();
  const color = getRandomMarkerColor();
  sessionState.optionStatus[optionId] = { done: true, marker, color };
  sessionState.lastCompletedOption = optionId;
  sessionState.sessionCount += 1;
}

async function executeMenuOption(optionId) {
  sessionState.selectedOption = optionId;
  // Always wipe previous menu content before entering any option
  clearScreen();

  try {
    if (optionId === 1) {
      const res = await selectVolumesMenu();
      if (res && res.changed) markOptionCompleted(1);
      return;
    }
    if (optionId === 11) { await showInformations(); markOptionCompleted(11); return; }
    if (optionId === 12) { await executeSystemDepsMenu(); markOptionCompleted(12); return; }
    if (optionId === 13) { await showHelp(); markOptionCompleted(13); return; }
    if (optionId === 14) { await showAdvancedOptions(); markOptionCompleted(14); return; }

    // volume-based operations
    const needsVolume = [2,3,4,5,6,7,8,9,10,15,16,17].includes(optionId);
    if (needsVolume && sessionState.selectedVolumes.length === 0) {
      await showResultScreen({ title: 'Volume selection required', status: 'warning', summaryLines: ['Please select NTFS volume(s) first (option 1).'] });
      const res = await selectVolumesMenu();
      if (!(res && res.changed) && sessionState.selectedVolumes.length === 0) return;
    }

    // root warning for write operations
    if (!isRoot() && [2,5,6,7,8,9,10,15,16,17].includes(optionId)) {
      const { cont } = await safePrompt([{ type: 'confirm', name: 'cont', message: colors.warning('Not running as root. Many operations may fail. Continue anyway?'), default: false }], 'root warning confirmation');
      if (!cont) return;
    }

    const result = await executeVolumeOperation(optionId);
    if (result && result.completed) markOptionCompleted(optionId);
  } finally {
    sessionState.selectedOption = null;
  }
}

function renderMenuChoice(opt) {
  const status = sessionState.optionStatus[opt.id];
  const done = !!(status && status.done);
  const markerChar = done ? status.marker : sessionState.initialMarkers[opt.id];
  const markerColorFn = done ? status.color : colors.bracketWhite;
  const marker = colors.bracketWhite('[') + markerColorFn(markerChar) + colors.bracketWhite(']');
  const label = colors.optionLabel(opt.label.padEnd(26));
  // inquirer prefix (2) + "[x] " (4) + "NN " (3) + label (26) + space (1) = 36 columns
  const room = termCols() - 36 - 1;
  const desc = room >= 12 ? colors.optionDesc(truncate(opt.desc, room)) : '';
  return `${marker} ${colors.optionNumber(String(opt.id).padStart(2, '0'))} ${label} ${desc}`.trimEnd();
}

async function showMainMenu() {
  while (true) {
    clearScreen();
    await sleep(30); // let terminal apply clear before redraw (avoids option-4 residue)
    clearScreen();
    await drawFullInterface({ showVolumes: true, showMountingErrors: true });
    initializeMarkers();
    const choices = MENU_OPTIONS.map(opt => ({ name: renderMenuChoice(opt), value: opt.id, short: `${opt.id}. ${opt.label}` }));
    choices.push(new inquirer.Separator());
    choices.push({ name: colors.warning('[x] Exit'), value: 'exit' });

    const ans = await safePrompt([{
      type: 'list',
      name: 'option',
      message: colors.info('Select an option:'),
      choices,
      pageSize: 22,
      loop: false,
    }], 'main menu');

    if (ans.option === 'exit') {
      clearScreen();
      console.log(colors.success('NTFS-REPAIR closed.'));
      process.exit(0);
    }

    await executeMenuOption(ans.option);
    // clean redraw after each action/return (esp. after option 4)
    clearScreen();
    await sleep(30);
    clearScreen();
  }
}

// ============================================
// ENTRY POINT
// ============================================

function checkTTY() {
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    console.error(colors.danger('Error: NTFS-REPAIR requires an interactive terminal (TTY).'));
    console.error(colors.warning('This application uses interactive menus that need a real terminal.'));
    console.error(colors.info('Please run directly in a terminal: sudo ntfs-repair'));
    console.error(colors.info('Or use: sudo ksvn  /  sudo ntfsre-pair'));
    console.error('');
    console.error(colors.dim('Note: Running via background jobs, pipes, timeout, or non-TTY launchers will not work.'));
    process.exit(1);
  }
}

async function main() {
  checkTTY();
  
  if (!isRoot()) {
    console.log(colors.warning('⚠  Warning: many operations require root privileges.'));
    console.log(colors.info('   Run with: sudo ntfs-repair (or sudo ksvn / sudo ntfsre-pair)'));
    console.log('');
    await sleep(800);
  }
  clearScreen();
  try {
    await showMainMenu();
  } catch (err) {
    if (err && err.code === 'ERR_USE_AFTER_CLOSE') {
      console.error(colors.danger('\nTerminal input was closed unexpectedly.'));
      console.error(colors.info('Please run NTFS-REPAIR directly in an interactive terminal.'));
      process.exit(1);
    }
    throw err;
  }
}

function fatal(err) {
  try { clearScreen(); } catch (_) {}
  console.error(colors.danger('Fatal error:'));
  console.error(err && err.stack ? err.stack : err);
  process.exit(1);
}

process.on('uncaughtException', fatal);
process.on('unhandledRejection', fatal);
// make sure the cursor is visible again whichever way we exit
process.on('exit', () => { try { process.stdout.write('\x1b[?25h'); } catch (_) {} });

main().catch(fatal);
