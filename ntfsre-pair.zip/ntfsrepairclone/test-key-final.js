#!/usr/bin/env node
// Syntax check + regression guards for the bug that made the app exit silently ~2 s after start.
const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const app = path.join(__dirname, 'index.js');
if (!fs.existsSync(app)) { console.error('FAIL: missing index.js'); process.exit(1); }
cp.execFileSync(process.execPath, ['--check', app], { stdio: 'inherit' });

// look at code only: the explanation of the bug in index.js comments mentions these calls too
const src = fs.readFileSync(app, 'utf8')
  .replace(/\/\*[\s\S]*?\*\//g, '')
  .replace(/(^|\s)\/\/.*$/gm, '$1');
const fail = (m) => { console.error('FAIL: ' + m); process.exit(1); };

// 1) `new Chafa()` / `new Chafa({})` starts a terminal probe that pauses stdin.
if (/new Chafa\(\s*\)/.test(src)) fail('found `new Chafa()` without arguments (stdin-pausing terminal probe)');
// 2) pixelMode, cellW and cellH must ALL be passed explicitly - otherwise the probe still runs.
const ctor = src.match(/new Chafa\(\{[\s\S]*?\}\)/);
if (!ctor) fail('Chafa constructor call not found');
for (const key of ['pixelMode', 'cellW', 'cellH']) {
  if (!new RegExp('\\b' + key + '\\b').test(ctor[0])) fail(`Chafa constructor must pass "${key}" explicitly`);
}
// 3) keys the library does not know are silently ignored.
if (/updateConfig\(\{[^}]*\b(width|height|symbolGlyphs)\b/.test(src)) fail('updateConfig uses unsupported keys (use termW/termH)');
// 4) a failing static-chafa load must not crash the app at startup.
if (/^const \{ Chafa \} = require\('static-chafa'\)/m.test(src)) fail('static-chafa must be loaded inside try/catch');
console.log('OK: index.js syntax valid; static-chafa is initialised without the stdin-pausing probe.');
