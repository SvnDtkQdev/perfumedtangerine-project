#!/bin/bash
# NTFS-REPAIR installer — npm deps + system tools + global commands
# Version 13.0.9 — Svn DtkQdev

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "========================================="
echo "  NTFS-REPAIR Installation Script"
echo "  Version 13.0.9 — Svn DtkQdev"
echo "========================================="
echo ""

if ! command -v node >/dev/null 2>&1; then
  echo "❌ Node.js is required (>= 18)."
  exit 1
fi
if ! command -v npm >/dev/null 2>&1; then
  echo "❌ npm is required."
  exit 1
fi

NODE_VERSION=$(node --version | sed 's/v//')
MAJOR_VERSION=$(echo "$NODE_VERSION" | cut -d. -f1)
if [ "$MAJOR_VERSION" -lt 18 ]; then
  echo "❌ Node.js >= 18 required (found $NODE_VERSION)"
  exit 1
fi
echo "✅ Node.js $NODE_VERSION"
echo "✅ npm $(npm --version)"

echo ""
echo "Installing npm dependencies in: $SCRIPT_DIR"
npm install

# ---------- System dependencies (always on install) ----------
echo ""
echo "Installing system dependencies (ntfs-3g, ntfsprogs, badblocks, util-linux tools)..."

run_as_root() {
  if [ "${EUID:-$(id -u)}" -eq 0 ]; then
    "$@"
  else
    sudo "$@"
  fi
}

install_system_pkgs() {
  if command -v pacman >/dev/null 2>&1; then
    echo "  Detected Arch/CachyOS (pacman)"
    run_as_root pacman -S --needed --noconfirm ntfs-3g ntfsprogs e2fsprogs util-linux psmisc coreutils 2>/dev/null \
      || run_as_root pacman -S --needed --noconfirm ntfs-3g e2fsprogs util-linux psmisc coreutils
  elif command -v apt-get >/dev/null 2>&1; then
    echo "  Detected Debian/Ubuntu (apt)"
    run_as_root apt-get update -qq
    run_as_root apt-get install -y ntfs-3g ntfs-3g-dev ntfsprogs e2fsprogs util-linux psmisc coreutils 2>/dev/null \
      || run_as_root apt-get install -y ntfs-3g e2fsprogs util-linux psmisc coreutils
  elif command -v dnf >/dev/null 2>&1; then
    echo "  Detected Fedora (dnf)"
    run_as_root dnf install -y ntfs-3g ntfsprogs e2fsprogs util-linux psmisc coreutils
  elif command -v zypper >/dev/null 2>&1; then
    echo "  Detected openSUSE (zypper)"
    run_as_root zypper install -y ntfs-3g ntfsprogs e2fsprogs util-linux psmisc coreutils
  else
    echo "  ⚠ Unknown package manager — install manually: ntfs-3g, e2fsprogs (badblocks), util-linux"
    echo "  Optional local source build: sudo bash ./install-system-deps.sh"
    return 0
  fi
}

install_system_pkgs || echo "  ⚠ System package install had errors — check output above."

echo ""
echo "Verifying system tools..."
MISSING_NTFSFIX=0
for cmd in ntfsfix ntfs-3g ntfsinfo badblocks blkid lsblk findmnt mount umount dd blockdev; do
  if command -v "$cmd" >/dev/null 2>&1; then
    echo "  ✅ $cmd -> $(command -v "$cmd")"
  else
    echo "  ⚠  $cmd not found in PATH"
    [ "$cmd" = "ntfsfix" ] && MISSING_NTFSFIX=1
  fi
done

if [ "$MISSING_NTFSFIX" = "1" ] && [ -f "$SCRIPT_DIR/install-system-deps.sh" ]; then
  echo ""
  echo "ntfsfix still missing — attempting local source build (install-system-deps.sh)..."
  run_as_root bash "$SCRIPT_DIR/install-system-deps.sh" || echo "  ⚠ local source build failed or incomplete"
fi

echo ""
echo "Installing global commands (ntfs-repair, ksvn, ntfsre-pair) from this folder..."
if [ "${EUID:-$(id -u)}" -ne 0 ]; then
  echo "⚠  Global install may require sudo. Attempting without sudo first..."
  if npm install -g .; then
    :
  else
    echo "Retrying with sudo..."
    sudo npm install -g .
  fi
else
  npm install -g .
fi

# Ensure local launchers are executable
chmod +x "$SCRIPT_DIR/ntfs-repair" "$SCRIPT_DIR/ksvn" "$SCRIPT_DIR/ntfsre-pair" "$SCRIPT_DIR/index.js" 2>/dev/null || true

echo ""
echo "Verifying commands..."
for cmd in ntfs-repair ksvn ntfsre-pair; do
  if command -v "$cmd" >/dev/null 2>&1; then
    echo "  ✅ $cmd -> $(command -v "$cmd")"
  else
    echo "  ⚠  $cmd not found in PATH yet (try: hash -r)"
  fi
done

echo ""
echo "Optional: also build local copies under ./deps from source:"
echo "  sudo bash ./install-system-deps.sh"
echo ""
echo "Run (after install, from PATH):"
echo "  sudo ntfs-repair"
echo "  sudo ksvn"
echo "  sudo ntfsre-pair"
echo ""
echo "Or from this folder:"
echo "  sudo ./ntfs-repair"
